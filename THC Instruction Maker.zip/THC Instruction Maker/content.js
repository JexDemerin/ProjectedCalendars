(() => {
  // src/lib/safety.js
  var RISKY_PATTERNS = [
    /\bsubmit/i,
    /\bsend\b/i,
    /\bdelete/i,
    /\bremove\b/i,
    /\bsave\b/i,
    /\bconfirm/i,
    /\bpay\b/i,
    /\bpayment/i,
    /\bapprove/i,
    /\breject/i,
    /\bdeny\b/i,
    /\bdecline\b/i,
    /\bpublish/i,
    /\bpost\b/i,
    /\barchive/i,
    /\bdeactivate/i,
    /\bdisable\b/i,
    /\bterminate/i,
    /\bcancel (visit|shift|appointment|booking|order|subscription|request)/i,
    /\bsign\b(?! in| up)/i,
    /\bplace order/i,
    /\bcheckout\b/i,
    /\binvite\b/i,
    /\bupload\b/i,
    /\bimport\b/i,
    /\btransfer\b/i,
    /\bclock (in|out)/i,
    /\bcheck (in|out)\b/i,
    /\bpunch (in|out)/i,
    /\bfinish\b/i,
    /\bcomplete\b/i,
    /\bfinalize/i,
    /\bupdate\b/i,
    /\bassign\b/i,
    /\bbook\b/i,
    /\breset password/i,
    /\blog ?out\b/i,
    /\bsign ?out\b/i,
    /\bsync\b/i
  ];
  function isRiskyLabel(label, extraWords = []) {
    const text = (label || "").trim();
    if (!text) return false;
    if (RISKY_PATTERNS.some((re) => re.test(text))) return true;
    return extraWords.some((w) => w && text.toLowerCase().includes(w.toLowerCase()));
  }

  // src/lib/fakes.js
  var KINDS = ["name", "phone", "email", "address", "date", "id", "note", "other"];
  var NAMES = [
    "Pat Placeholder",
    "Alex Sample",
    "Sam Example",
    "Chris Demo",
    "Taylor Test",
    "Jordan Sample",
    "Casey Example",
    "Morgan Demo",
    "Riley Test",
    "Jamie Sample"
  ];
  function makeFake(kind, n, real = "") {
    switch (kind) {
      case "name": {
        const base = NAMES[n % NAMES.length];
        const full = n >= NAMES.length ? `${base} ${Math.floor(n / NAMES.length) + 1}` : base;
        return real.trim().split(/\s+/).length === 1 ? full.split(" ")[0] : full;
      }
      case "phone":
        return `555-01${String((n + 1) % 100).padStart(2, "0")}`;
      case "email":
        return `sample${n + 1}@example.com`;
      case "address":
        return `${101 + n} Sample Street`;
      case "date":
        return "01/01/2000";
      case "id":
        return `SAMPLE-${String(n + 1).padStart(4, "0")}`;
      case "note":
        return "Sample note.";
      default:
        return "Sample";
    }
  }
  var EMAIL = /^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i;
  var PHONE = /^\+?[\d\s().-]{7,}$/;
  var DATE = /^(\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}|\d{4}-\d{2}-\d{2}|[a-z]{3,9}\.? \d{1,2},? \d{4})$/i;
  var ADDRESS = /^\d{1,6}\s+\S+.*\b(street|st|avenue|ave|road|rd|blvd|lane|ln|drive|dr|court|ct|way|place|pl|brgy|barangay)\b/i;
  var PERSON = /^[A-Z][A-Za-z'.-]+(\s+[A-Z][A-Za-z'.-]+){0,3}$/;
  function kindFromValue(value) {
    const v = (value || "").trim();
    if (EMAIL.test(v)) return "email";
    if (DATE.test(v)) return "date";
    if (ADDRESS.test(v)) return "address";
    if (PHONE.test(v) && v.replace(/\D/g, "").length >= 7) return "phone";
    if (/^[A-Z0-9-]{4,}$/i.test(v) && /\d/.test(v)) return "id";
    if (PERSON.test(v)) return "name";
    return v.length > 40 ? "note" : "other";
  }
  function kindFromHint(hint) {
    const h = (hint || "").toLowerCase();
    if (KINDS.includes(h)) return h;
    if (/e-?mail/.test(h)) return "email";
    if (/phone|mobile|cell|tel\b/.test(h)) return "phone";
    if (/address|street|city|zip|postal/.test(h)) return "address";
    if (/dob|birth|date/.test(h)) return "date";
    if (/ssn|social security|medicaid|medicare|insurance|member|policy|license|account|routing|\bid\b/.test(h)) return "id";
    if (/diagnos|medication|allerg|condition|note|comment/.test(h)) return "note";
    if (/name|client|patient|caregiver|guardian|contact|staff|employee/.test(h)) return "name";
    return "";
  }

  // src/lib/names.js
  var LIST = `
aaron abby abel abigail abraham adam adela adelaida adelina adrian adriana agnes agustin aida aileen aimee alan albert alberto
alejandra alejandro alex alexa alexander alexandra alexis alfonso alfred alfredo alice alicia alina alison allan allen alma alvin
alyssa amanda amber amelia amy ana analyn andre andrea andres andrew andy angel angela angelica angelina angelito angelo anita
ann anna anne annie anthony antonia antonio araceli ariel arlene armando arnel arnold arturo ashley audrey aurora austin
ava barbara beatriz belen ben benedict benito benjamin bernadette bernard bernardo betty beverly bianca billy bobby bonifacio
brandon brenda brian bridget brittany bruce bryan caleb camila camille candice carina carl carla carlos carlito carmela carmelita
carmen carol carolina caroline carrie cassandra catalina catherine cecilia celia cesar charlene charles charlie charlotte chelsea
cheryl chloe christian christina christine christopher cindy claire clara clarissa claudia clifford connie consuelo corazon cristina
cristy cynthia daisy dale dalisay damian dan daniel daniela danilo danny darlene darwin david dean debbie deborah
delia denise dennis derek diana diane diego dolores dominic dominador donald donna dora doris dorothy douglas dylan edgar edith
edna eduardo edward edwin efren eileen elaine elena elias elijah elisa elizabeth ella ellen elmer eloisa elsa elvira emilio emily
emma emmanuel enrique erica eric erik erika erlinda ernesto esperanza esteban estela estrella ethan eugene eugenia eva evan evelyn
fatima felicidad felipe felix fernando fidel flor florencia florentino flora frances francesca francis francisco frank franklin
fred frederick gabriel gabriela gail gary genaro geraldine gerardo gilbert gina gladys glenda gloria gonzalo gregorio gregory
guadalupe guillermo gustavo hannah harold harry hazel heather hector helen henry herminia hernan hilda hugo ian ignacio imelda
irene iris irma isaac isabel isabella isidro ismael ivan jack jackie jacob jacqueline jaime jake james jamie jan jane janet janice
jasmine jason javier jay jean jeanette jeff jeffrey jenelyn jennifer jenny jeremy jericho jerome jerry jesse jessica jesus jill
jimmy joan joana joanna joaquin jocelyn joe joel john johnny jomar jonathan jorge jose josefa josefina joseph josephine joshua
juan juana juanita judith judy julia julian juliana julie julio julius justin karen karina karl kate katherine kathleen kathryn
katrina kayla keith kelly kenneth kevin kimberly kristine kyle larry laura lauren lawrence leah leila leonardo leonor leslie
leticia lilia liliana lillian linda lisa liza lorena lorenzo loretta lorna louis lourdes lucas lucia luciana lucy luis luisa
luz lydia lynn mabel madison maggie manuel manuela marco marcos margaret margarita maria mariana maribel maricel maricris
marie mariel marilou marilyn marina mario marisol maritess marjorie marlon marta martha martin marvin mary matthew maureen
maxine megan melanie melissa melinda melvin mercedes michael michelle miguel milagros mildred miriam mitchell monica nancy
natalia natalie nathan nelson nestor nicholas nicole noel noemi nora norma oliver olivia oscar pablo pamela paolo patricia
patrick paul paula pauline pedro perla peter philip pilar priscilla rachel rafael ramon randy raquel raul ray raymond rebecca
regina reginald renato rene reynaldo ricardo richard rick ricky rita robert roberto robin rodel rodolfo rodrigo rogelio roger
rolando romeo ronald ronaldo ronnie rosa rosalie rosalinda rosana rosario rose rosemarie roxanne ruben ruby rudy russell ruth
ryan salvador samantha samuel sandra santiago santos sara sarah sergio sharon sheila shirley sofia sonia stephanie stephen
steven susan susana sylvia tamara tanya teodoro teresa teresita terry thelma theresa thomas timothy tina todd tomas tony
tracy trinidad tyler valentina valerie vanessa veronica vicente victor victoria vilma vincent violeta virgilio virginia vivian
walter wendy wilfredo william wilma xavier yolanda yvonne zenaida zoe
`;
  var FIRST_NAMES = new Set(LIST.split(/\s+/).filter(Boolean));
  var NOT_SURNAME = /* @__PURE__ */ new Set(["welcome", "hello", "hi", "dear", "thanks", "thank", "client", "caregiver", "patient", "name", "contact", "by", "for", "with", "from", "to", "and", "or", "mr", "mrs", "ms", "dr"]);
  var PARTICLES = /* @__PURE__ */ new Set(["de", "del", "dela", "la", "van", "von", "da", "dos", "delos", "san", "st."]);
  var isCap = (w) => /^[A-ZÀ-Þ][A-Za-zÀ-ÿ'’.-]*$/.test(w) && /[a-zß-ÿ]/.test(w);
  var key = (w) => w.toLowerCase().replace(/[.’',]/g, "");
  function findPersonNames(text) {
    const words = [];
    const re = /\S+/g;
    let m;
    while (m = re.exec(text)) words.push({ w: m[0], start: m.index, end: m.index + m[0].length });
    const out = [];
    for (let i = 0; i < words.length; i++) {
      const w = words[i].w.replace(/[,:;)]+$/, "");
      if (!isCap(w) || !FIRST_NAMES.has(key(w))) continue;
      const prev = words[i - 1];
      if (prev && /,$/.test(prev.w) && isCap(prev.w.slice(0, -1)) && !NOT_SURNAME.has(key(prev.w)) && !FIRST_NAMES.has(key(prev.w))) {
        out.push({ start: prev.start, end: words[i].start + w.length });
        continue;
      }
      let j = i + 1;
      let last = -1;
      while (j < words.length && j <= i + 4) {
        const raw = words[j].w;
        const t = raw.replace(/[,:;.)]+$/, "");
        if (PARTICLES.has(t.toLowerCase())) {
          j++;
          continue;
        }
        if (!isCap(t)) break;
        last = j;
        j++;
        if (raw !== t) break;
      }
      if (last > 0) {
        const endWord = words[last];
        out.push({ start: words[i].start, end: endWord.start + endWord.w.replace(/[,:;.)]+$/, "").length });
        i = last;
      }
    }
    return out;
  }

  // src/content.js
  (() => {
    const VERSION = 6;
    if (window.__IM && window.__IM.version === VERSION) return;
    const SENSITIVE_WORDS = /(name|dob|birth|phone|mobile|cell|tel\b|email|e-mail|address|street|city|zip|postal|ssn|social security|medicaid|medicare|insurance|member|policy|patient|client|caregiver|guardian|emergency|contact|diagnos|medication|allerg|condition|notes?\b|comment|license|account|routing|salary|pay ?rate|wage|gender|age\b)/i;
    const EMAIL2 = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi;
    const PHONE2 = /(\+?\d{1,3}[\s.-]?)?(\(\d{2,4}\)|\d{2,4})[\s.-]\d{3,4}[\s.-]\d{3,4}\b|\b09\d{2}[\s.-]?\d{3}[\s.-]?\d{4}\b/g;
    const SSN = /\b\d{3}-\d{2}-\d{4}\b/g;
    const ADDRESS2 = /\b\d{1,6}\s+(?:[A-Za-z0-9.'-]+\s){0,5}(?:street|st|avenue|ave|road|rd|boulevard|blvd|lane|ln|drive|dr|court|ct|way|place|pl|terrace|circle|cir|highway|hwy|barangay|brgy)\b\.?/gi;
    const DATE2 = /\b(?:\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}|\d{4}-\d{2}-\d{2}|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.? \d{1,2},? \d{4})\b/gi;
    const INLINE_LABEL = /\b(name|client|patient|caregiver|phone|mobile|email|address|dob|date of birth|birthday|ssn|medicaid|medicare|member id|emergency contact)\s*:\s*(\S.*)$/i;
    const REDACT_SELECTOR = '[data-sensitive],[data-private],[data-redact],[data-phi],.redact,.sensitive,.phi,[class*="avatar" i]';
    const INTERACTIVE_SELECTOR = [
      "a[href]",
      "button",
      "input:not([type=hidden])",
      "select",
      "textarea",
      "summary",
      "[role=button]",
      "[role=link]",
      "[role=tab]",
      "[role=menuitem]",
      "[role=menuitemcheckbox]",
      "[role=menuitemradio]",
      "[role=checkbox]",
      "[role=radio]",
      "[role=switch]",
      "[role=option]",
      "[role=combobox]",
      "[role=treeitem]",
      '[contenteditable=""]',
      "[contenteditable=true]",
      "[onclick]"
    ].join(",");
    const clean = (s, max = 100) => (s || "").replace(/\s+/g, " ").trim().slice(0, max);
    function viewport() {
      return { w: window.innerWidth, h: window.innerHeight, dpr: window.devicePixelRatio || 1 };
    }
    function isVisible(el) {
      const r = el.getBoundingClientRect();
      if (r.width < 2 || r.height < 2) return false;
      const cs = getComputedStyle(el);
      return cs.visibility !== "hidden" && cs.display !== "none" && Number(cs.opacity) > 0.05;
    }
    function inViewport(r) {
      return r.bottom > 0 && r.right > 0 && r.top < window.innerHeight && r.left < window.innerWidth;
    }
    function textOfIds(ids) {
      return ids.split(/\s+/).map((id) => document.getElementById(id)?.innerText || "").join(" ");
    }
    function fieldLabel(el) {
      if (el.labels && el.labels.length) return [...el.labels].map((l) => l.innerText).join(" ");
      const wrap = el.closest("label");
      return wrap ? wrap.innerText : "";
    }
    function accessibleName(el) {
      const aria = el.getAttribute("aria-label");
      if (aria) return clean(aria);
      const by = el.getAttribute("aria-labelledby");
      if (by) {
        const t = clean(textOfIds(by));
        if (t) return t;
      }
      const tag = el.tagName.toLowerCase();
      if (tag === "input" || tag === "select" || tag === "textarea") {
        const lbl = clean(fieldLabel(el));
        if (lbl) return lbl;
        if (["button", "submit", "reset"].includes(el.type)) return clean(el.value);
        return clean(el.getAttribute("placeholder") || el.name || el.id || "");
      }
      const text = clean(el.innerText);
      if (text) return text;
      const img = el.querySelector("img[alt]");
      if (img) return clean(img.alt);
      const svgTitle = el.querySelector("svg title");
      if (svgTitle) return clean(svgTitle.textContent);
      return clean(el.getAttribute("title") || "");
    }
    function contextFor(el) {
      const dialog = el.closest("dialog,[role=dialog],[role=alertdialog],[aria-modal=true]");
      if (dialog) return "dialog: " + clean(dialog.getAttribute("aria-label") || dialog.querySelector("h1,h2,h3,[role=heading]")?.innerText || "", 60);
      if (el.closest("nav,[role=navigation]")) return "navigation menu";
      if (el.closest("header,[role=banner]")) return "page header";
      if (el.closest("aside")) return "sidebar";
      const form = el.closest("form");
      if (form) return "form: " + clean(form.getAttribute("aria-label") || form.querySelector("h1,h2,h3,legend")?.innerText || "", 60);
      if (el.closest("table,[role=grid],[role=table]")) return "table";
      return "";
    }
    function isSubmitLike(el) {
      const tag = el.tagName.toLowerCase();
      const type = (el.getAttribute("type") || "").toLowerCase();
      const inForm = !!el.form || !!el.closest("form");
      if (!inForm) return false;
      const form = el.form || el.closest("form");
      if (form.getAttribute("role") === "search" || form.querySelector("input[type=search]")) return false;
      if (tag === "button") return type === "" || type === "submit";
      return tag === "input" && (type === "submit" || type === "image");
    }
    const MAX_ELEMENTS = 300;
    const MAX_MARKERS = 40;
    const MARKER_SELECTOR = '.leaflet-marker-icon,.leaflet-marker-pane *,.leaflet-interactive,gmp-advanced-marker,.gm-style [role=button][title],.gm-style [role=img][title],.mapboxgl-marker,.maplibregl-marker,[class*="marker" i],[class*="pin" i][aria-label]';
    const MAP_SELECTOR = '.leaflet-container,.gm-style,.mapboxgl-map,.maplibregl-map,.ol-viewport,[class*="map" i][class*="container" i]';
    function isMapMarker(el) {
      if (el.matches(MARKER_SELECTOR) || el.closest(".leaflet-marker-pane,.leaflet-overlay-pane")) return true;
      const map = el.closest(MAP_SELECTOR);
      if (!map || el.closest('.leaflet-control-container,.gmnoprint,.gm-control-active,.mapboxgl-control-container,[class*="legend" i],[class*="control" i]')) return false;
      const r = el.getBoundingClientRect();
      return r.width <= 48 && r.height <= 48;
    }
    function pointerElements() {
      const out = [];
      const nodes = document.body ? document.body.getElementsByTagName("*") : [];
      for (let i = 0; i < nodes.length && i < 6e3; i++) {
        const el = nodes[i];
        if (el.matches(INTERACTIVE_SELECTOR) || el.closest(INTERACTIVE_SELECTOR)) continue;
        if (/^(svg|path|g|use|script|style|br|img)$/i.test(el.tagName)) continue;
        if (getComputedStyle(el).cursor !== "pointer") continue;
        const parent = el.parentElement;
        if (parent && getComputedStyle(parent).cursor === "pointer") continue;
        const text = clean(el.innerText, 80);
        if (!text && !el.getAttribute("aria-label") && !el.getAttribute("title")) continue;
        if (text.length > 60) continue;
        out.push(el);
      }
      return out;
    }
    function collectPage(opts = {}) {
      const extraRisky = opts.extraRiskyWords || [];
      document.querySelectorAll("[data-im-id]").forEach((el) => el.removeAttribute("data-im-id"));
      const all = [.../* @__PURE__ */ new Set([...document.querySelectorAll(INTERACTIVE_SELECTOR), ...pointerElements()])].filter(isVisible);
      const rank = (el) => (isMapMarker(el) ? 2 : 0) + (inViewport(el.getBoundingClientRect()) ? 0 : 1);
      all.sort((a, b) => rank(a) - rank(b));
      let markers = 0;
      const picked = [];
      for (const el of all) {
        if (isMapMarker(el) && ++markers > MAX_MARKERS) continue;
        picked.push(el);
        if (picked.length >= MAX_ELEMENTS) break;
      }
      const elements = [];
      let id = 1;
      for (const el of picked) {
        if (el.closest("[data-im-id]") && !["INPUT", "SELECT", "TEXTAREA"].includes(el.tagName)) {
          const parent = el.parentElement?.closest("[data-im-id]");
          if (parent && accessibleName(parent) === accessibleName(el)) continue;
        }
        el.setAttribute("data-im-id", String(id));
        const r = el.getBoundingClientRect();
        const label = accessibleName(el);
        const tag = el.tagName.toLowerCase();
        const info = {
          id,
          tag,
          role: el.getAttribute("role") || "",
          type: el.getAttribute("type") || "",
          label,
          on_screen: inViewport(r),
          context: contextFor(el),
          risky: isRiskyLabel(label, extraRisky) || isSubmitLike(el)
        };
        if (isMapMarker(el)) info.map_pin = true;
        if (tag === "a") {
          try {
            info.href = new URL(el.href).pathname;
          } catch {
          }
        }
        if (tag === "select") info.options = [...el.options].slice(0, 30).map((o) => clean(o.text, 40));
        if ("checked" in el && (el.type === "checkbox" || el.type === "radio")) info.checked = el.checked;
        if (el.disabled || el.getAttribute("aria-disabled") === "true") info.disabled = true;
        if (el.getAttribute("aria-expanded")) info.expanded = el.getAttribute("aria-expanded") === "true";
        if (el.getAttribute("aria-selected") === "true" || el.getAttribute("aria-current")) info.current = true;
        elements.push(info);
        id++;
      }
      const headings = [...document.querySelectorAll("h1,h2,h3,[role=heading]")].filter(isVisible).slice(0, 15).map((h) => clean(h.innerText, 80)).filter(Boolean);
      return {
        url: location.href,
        title: document.title,
        viewport: viewport(),
        headings,
        dialog_open: !!document.querySelector("dialog[open],[role=dialog],[aria-modal=true]"),
        elements
      };
    }
    function* visibleTextNodes() {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
        acceptNode(n2) {
          if (!n2.nodeValue || !n2.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
          const p = n2.parentElement;
          if (!p || p.closest("script,style,noscript,template")) return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        }
      });
      let n;
      while (n = walker.nextNode()) {
        const p = n.parentElement;
        const r = p.getBoundingClientRect();
        if (!inViewport(r) || !isVisible(p)) continue;
        yield n;
      }
    }
    function rangeRects(node, start, end) {
      const range = document.createRange();
      range.setStart(node, start);
      range.setEnd(node, end);
      return [...range.getClientRects()];
    }
    function listTextCandidates(allowValues = []) {
      const seen = new Set(allowValues.map((v) => clean(v, 200)));
      const out = [];
      for (const n of visibleTextNodes()) {
        const t = clean(n.nodeValue, 200);
        if (t.length < 2 || seen.has(t)) continue;
        seen.add(t);
        out.push(t);
        if (out.length >= 400) break;
      }
      for (const el of document.querySelectorAll("[aria-label],[title],img[alt],[placeholder]")) {
        if (!isVisible(el) || !inViewport(el.getBoundingClientRect())) continue;
        for (const attr of ["aria-label", "title", "alt"]) {
          const v = clean(el.getAttribute(attr), 200);
          if (v.length >= 2 && !seen.has(v)) {
            seen.add(v);
            out.push(v);
          }
        }
      }
      for (const el of document.querySelectorAll("input,textarea")) {
        if (!isVisible(el) || !inViewport(el.getBoundingClientRect())) continue;
        const v = clean(el.value, 200);
        if (v.length >= 2 && !seen.has(v) && !["button", "submit", "reset", "checkbox", "radio"].includes(el.type)) {
          seen.add(v);
          out.push(v);
        }
      }
      return out;
    }
    function isClickable(e) {
      return !!(e.matches(INTERACTIVE_SELECTOR) || e.closest(INTERACTIVE_SELECTOR) || e.querySelector(INTERACTIVE_SELECTOR) || getComputedStyle(e).cursor === "pointer");
    }
    function collectTargets(opts) {
      const allow = new Set((opts.allowValues || []).map((v) => v.trim()).filter(Boolean));
      const flagged = (opts.flagged || []).filter((f) => f && f.text && f.text.trim().length >= 2);
      const t = { ranges: [], elements: [], fields: [], images: [] };
      const seenEl = /* @__PURE__ */ new Set();
      const el = (e, kind = "") => {
        if (!e || seenEl.has(e) || !isVisible(e) || !inViewport(e.getBoundingClientRect())) return;
        if ([...seenEl].some((s) => s.contains(e))) return;
        seenEl.add(e);
        t.elements.push({ el: e, kind });
      };
      const range = (node, start, end, kind) => t.ranges.push({ node, start, end, kind });
      for (const e of document.querySelectorAll(REDACT_SELECTOR)) {
        if (e.matches("img,picture,video,canvas") || /avatar/i.test(e.className) && !clean(e.innerText)) {
          if (isVisible(e) && inViewport(e.getBoundingClientRect())) t.images.push({ el: e });
        } else {
          el(e, kindFromHint(e.getAttribute("data-sensitive") || e.getAttribute("data-phi") || ""));
        }
      }
      for (const f of document.querySelectorAll('input,textarea,[contenteditable=""],[contenteditable=true]')) {
        if (!isVisible(f) || !inViewport(f.getBoundingClientRect())) continue;
        const type = (f.getAttribute("type") || "").toLowerCase();
        if (["button", "submit", "reset", "checkbox", "radio", "range", "color", "file", "hidden", "search", "password"].includes(type)) continue;
        const value = f.isContentEditable ? f.innerText : f.value;
        if (!value || !value.trim() || allow.has(value.trim())) continue;
        const hints = [f.name, f.id, f.getAttribute("placeholder"), f.getAttribute("aria-label"), f.getAttribute("autocomplete"), fieldLabel(f)].join(" ");
        const sensitive = opts.hideAllFieldValues || ["email", "tel", "date"].includes(type) || SENSITIVE_WORDS.test(hints) || flagged.some((x) => value.includes(x.text));
        if (!sensitive) continue;
        const kind = kindFromHint(type === "tel" ? "phone" : type === "email" ? "email" : hints) || kindFromValue(value);
        if (f.isContentEditable) el(f, kind);
        else t.fields.push({ el: f, kind });
      }
      for (const f of document.querySelectorAll("input[type=password]")) {
        if (f.value && isVisible(f) && inViewport(f.getBoundingClientRect())) t.images.push({ el: f });
      }
      for (const table of document.querySelectorAll("table")) {
        if (!inViewport(table.getBoundingClientRect())) continue;
        const headRow = table.tHead?.rows[0] || [...table.rows].find((r) => r.querySelector("th"));
        if (!headRow) continue;
        const cols = /* @__PURE__ */ new Map();
        let col = 0;
        for (const cell of headRow.cells) {
          const span = cell.colSpan || 1;
          if (SENSITIVE_WORDS.test(cell.innerText)) for (let k = 0; k < span; k++) cols.set(col + k, kindFromHint(cell.innerText));
          col += span;
        }
        if (!cols.size) continue;
        for (const row of table.rows) {
          if (row === headRow) continue;
          let c = 0;
          for (const cell of row.cells) {
            if (cols.has(c) && cell.tagName === "TD") el(cell, cols.get(c));
            c += cell.colSpan || 1;
          }
        }
      }
      for (const grid of document.querySelectorAll("[role=grid],[role=table],[role=treegrid]")) {
        const headers = [...grid.querySelectorAll("[role=columnheader]")];
        const idx = headers.map((h, i) => SENSITIVE_WORDS.test(h.innerText) ? i : -1).filter((i) => i >= 0);
        if (!idx.length) continue;
        for (const row of grid.querySelectorAll("[role=row]")) {
          const cells = [...row.querySelectorAll(":scope > [role=cell], :scope > [role=gridcell], :scope > [role=rowheader]")];
          for (const i of idx) if (cells[i]) el(cells[i], kindFromHint(headers[i].innerText));
        }
      }
      for (const dt of document.querySelectorAll("dt")) {
        if (!SENSITIVE_WORDS.test(dt.innerText)) continue;
        let dd = dt.nextElementSibling;
        while (dd && dd.tagName === "DD") {
          el(dd, kindFromHint(dt.innerText));
          dd = dd.nextElementSibling;
        }
      }
      for (const th of document.querySelectorAll("tbody th, tr > th:first-child")) {
        if (th.closest("thead") || !SENSITIVE_WORDS.test(th.innerText)) continue;
        for (const td of th.parentElement.querySelectorAll("td")) el(td, kindFromHint(th.innerText));
      }
      const LABEL_ONLY = /^\s*[\w\s/'.-]{1,30}:?\s*$/;
      for (const lab of document.querySelectorAll("label,span,div,p,strong,b,small,h4,h5,h6")) {
        if (lab.children.length > 0) continue;
        const text = lab.textContent || "";
        if (text.length > 32 || !LABEL_ONLY.test(text) || !SENSITIVE_WORDS.test(text)) continue;
        const labelLike = /:\s*$/.test(text) || lab.matches("label,strong,b,h4,h5,h6");
        if (!labelLike || isClickable(lab)) continue;
        const next = lab.nextElementSibling;
        const len = next ? clean(next.innerText).length : 0;
        if (next && !isClickable(next) && len > 0 && len < 200) el(next, kindFromHint(text));
      }
      for (const img of document.querySelectorAll("img,picture,video,canvas")) {
        if (!isVisible(img)) continue;
        const r = img.getBoundingClientRect();
        if (!inViewport(r)) continue;
        const hints = [img.alt, img.className, img.id, img.getAttribute("src")].join(" ");
        const round = parseFloat(getComputedStyle(img).borderRadius) >= Math.min(r.width, r.height) * 0.4;
        if (/avatar|profile|photo|headshot|user|face|picture|selfie|portrait/i.test(hints) || round && r.width <= 256) t.images.push({ el: img });
      }
      const patterns = [[EMAIL2, "email"], [PHONE2, "phone"], [SSN, "id"], [ADDRESS2, "address"]];
      if (opts.hideDates) patterns.push([DATE2, "date"]);
      for (const node of visibleTextNodes()) {
        if ([...seenEl].some((s) => s.contains(node))) continue;
        const text = node.nodeValue;
        for (const [re, kind] of patterns) {
          re.lastIndex = 0;
          let m;
          while (m = re.exec(text)) {
            if (m[0].length === 0) {
              re.lastIndex++;
              continue;
            }
            range(node, m.index, m.index + m[0].length, kind);
          }
        }
        for (const r of findPersonNames(text)) range(node, r.start, r.end, "name");
        const inline = INLINE_LABEL.exec(text);
        if (inline) {
          const start = text.indexOf(inline[2], inline.index + inline[1].length);
          range(node, start, start + inline[2].length, kindFromHint(inline[1]) || "other");
        }
        for (const f of flagged) {
          let from = 0;
          let i;
          while ((i = text.indexOf(f.text, from)) !== -1) {
            range(node, i, i + f.text.length, f.kind || kindFromValue(f.text));
            from = i + f.text.length;
          }
        }
      }
      return t;
    }
    function computeRedactions(opts = {}) {
      const rects = [];
      const pad = 3;
      const overlays = openOverlays();
      const pushRect = (r, owner) => {
        if (!r || r.width < 1 || r.height < 1 || !inViewport(r)) return;
        let pieces = [{ x: r.left - pad, y: r.top - pad, w: r.width + pad * 2, h: r.height + pad * 2 }];
        for (const o of overlays) {
          if (owner && o.el.contains(owner)) continue;
          pieces = pieces.flatMap((p) => subtract(p, o.rect));
        }
        rects.push(...pieces.filter((p) => p.w >= 1 && p.h >= 1));
      };
      const t = collectTargets(opts);
      for (const x of [...t.elements, ...t.fields, ...t.images]) pushRect(x.el.getBoundingClientRect(), x.el);
      for (const x of t.ranges) rangeRects(x.node, x.start, x.end).forEach((r) => pushRect(r, x.node.parentElement));
      return { viewport: viewport(), rects };
    }
    let swapped = null;
    function textNodesIn(root) {
      const out = [];
      const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
      let n;
      while (n = w.nextNode()) if (n.nodeValue && n.nodeValue.trim()) out.push(n);
      return out;
    }
    async function applyFakes(opts = {}, fakeMap = {}) {
      restoreFakes();
      const map = { ...fakeMap };
      const counts = {};
      for (const v of Object.values(map)) counts[v.kind] = (counts[v.kind] || 0) + 1;
      const fakeFor = (real, kind) => {
        const key2 = clean(real, 500);
        if (!key2) return real;
        if (map[key2]) return map[key2].fake;
        const k = kind || kindFromValue(key2);
        const n = counts[k] || 0;
        counts[k] = n + 1;
        const fake = makeFake(k, n, key2);
        map[key2] = { fake, kind: k };
        return fake;
      };
      const t = collectTargets(opts);
      const edits = /* @__PURE__ */ new Map();
      const editFor = (node) => {
        if (!edits.has(node)) edits.set(node, { whole: null, ranges: [] });
        return edits.get(node);
      };
      for (const x of t.elements) {
        const nodes = textNodesIn(x.el);
        if (!nodes.length) continue;
        const fake = fakeFor(x.el.innerText, x.kind);
        nodes.forEach((n, i) => {
          editFor(n).whole = i === 0 ? fake : "";
        });
      }
      for (const r of t.ranges) editFor(r.node).ranges.push(r);
      const texts = [];
      for (const [node, e] of edits) {
        const original = node.nodeValue;
        let value;
        if (e.whole !== null) {
          value = original.match(/^\s*/)[0] + e.whole + original.match(/\s*$/)[0];
        } else {
          const rs = e.ranges.sort((a, b) => a.start - b.start || b.end - a.end);
          let out = "";
          let pos = 0;
          for (const r of rs) {
            if (r.start < pos) continue;
            out += original.slice(pos, r.start) + fakeFor(original.slice(r.start, r.end), r.kind);
            pos = r.end;
          }
          value = out + original.slice(pos);
        }
        if (value === original) continue;
        node.nodeValue = value;
        texts.push({ node, original, fake: value });
      }
      const fields = [];
      for (const f of t.fields) {
        const original = f.el.value;
        const fake = fakeFor(original, f.kind);
        f.el.value = fake;
        fields.push({ el: f.el, original, fake });
      }
      swapped = { texts, fields };
      await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
      await new Promise((r) => setTimeout(r, 60));
      const placeholders = t.images.map((x) => x.el.getBoundingClientRect()).filter((r) => inViewport(r)).map((r) => ({ x: r.left, y: r.top, w: r.width, h: r.height }));
      return { viewport: viewport(), map, placeholders, swappedCount: texts.length + fields.length };
    }
    function restoreFakes() {
      if (!swapped) return { intact: true };
      let intact = true;
      for (const s of swapped.texts) {
        if (!s.node.isConnected || s.node.nodeValue !== s.fake) intact = false;
        else s.node.nodeValue = s.original;
      }
      for (const f of swapped.fields) {
        if (f.el.value !== f.fake) intact = false;
        else f.el.value = f.original;
      }
      swapped = null;
      return { intact };
    }
    function openOverlays() {
      const sel = "dialog[open],[role=dialog],[role=alertdialog],[aria-modal=true],[role=menu],[role=listbox],[popover]:popover-open";
      const out = [];
      for (const el of document.querySelectorAll(sel)) {
        if (!isVisible(el)) continue;
        const r = el.getBoundingClientRect();
        if (!inViewport(r)) continue;
        const top = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
        if (top && (el === top || el.contains(top))) out.push({ el, rect: { x: r.left, y: r.top, w: r.width, h: r.height } });
      }
      return out;
    }
    function subtract(a, b) {
      const ax2 = a.x + a.w, ay2 = a.y + a.h, bx2 = b.x + b.w, by2 = b.y + b.h;
      if (b.x >= ax2 || bx2 <= a.x || b.y >= ay2 || by2 <= a.y) return [a];
      const out = [];
      if (b.y > a.y) out.push({ x: a.x, y: a.y, w: a.w, h: b.y - a.y });
      if (by2 < ay2) out.push({ x: a.x, y: by2, w: a.w, h: ay2 - by2 });
      const top = Math.max(a.y, b.y), bottom = Math.min(ay2, by2);
      if (b.x > a.x) out.push({ x: a.x, y: top, w: b.x - a.x, h: bottom - top });
      if (bx2 < ax2) out.push({ x: bx2, y: top, w: ax2 - bx2, h: bottom - top });
      return out;
    }
    function byId(id) {
      return document.querySelector(`[data-im-id="${id}"]`);
    }
    function rectOf(el) {
      const r = el.getBoundingClientRect();
      return { x: r.left, y: r.top, w: r.width, h: r.height };
    }
    async function prepare(id) {
      const el = byId(id);
      if (!el) return { ok: false, error: `Element ${id} is no longer on the page.` };
      const r = el.getBoundingClientRect();
      if (r.top < 60 || r.bottom > window.innerHeight - 20 || r.left < 0 || r.right > window.innerWidth) {
        el.scrollIntoView({ block: "center", inline: "nearest", behavior: "instant" });
        await new Promise((res) => setTimeout(res, 350));
      }
      return { ok: true, rect: rectOf(el), focus: focusRect(el), viewport: viewport() };
    }
    function geometry(id) {
      const el = byId(id);
      if (!el) return { ok: false, error: `Element ${id} is no longer on the page.` };
      return { ok: true, rect: rectOf(el), focus: focusRect(el), viewport: viewport() };
    }
    function focusRect(el) {
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const target = el.getBoundingClientRect();
      const containers = 'dialog,[role=dialog],[role=alertdialog],[role=menu],[role=listbox],form,fieldset,nav,aside,section,article,[class*="card" i],[class*="panel" i],[class*="modal" i]';
      let node = el.parentElement;
      while (node && node !== document.body) {
        if (node.matches(containers)) {
          const r = node.getBoundingClientRect();
          const areaOk = r.width * r.height < vw * vh * 0.7;
          if (areaOk && r.width >= 280 && r.height >= 120 && r.width >= target.width) {
            return clampRect({ x: r.left - 16, y: r.top - 16, w: r.width + 32, h: r.height + 32 });
          }
        }
        node = node.parentElement;
      }
      const minW = Math.min(720, vw);
      const minH = Math.min(400, vh);
      const w = Math.max(minW, target.width + 160);
      const h = Math.max(minH, target.height + 160);
      const cx = target.left + target.width / 2;
      const cy = target.top + target.height / 2;
      return clampRect({ x: cx - w / 2, y: cy - h / 2, w, h });
    }
    function clampRect(r) {
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      let { x, y, w, h } = r;
      w = Math.min(w, vw);
      h = Math.min(h, vh);
      x = Math.max(0, Math.min(x, vw - w));
      y = Math.max(0, Math.min(y, vh - h));
      return { x, y, w, h };
    }
    function setNativeValue(el, value) {
      const proto = el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(proto, "value").set;
      setter.call(el, value);
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
    }
    function mouse(el, type) {
      const r = el.getBoundingClientRect();
      const opts = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, button: 0 };
      const Ctor = type.startsWith("pointer") && window.PointerEvent ? PointerEvent : MouseEvent;
      el.dispatchEvent(new Ctor(type, opts));
    }
    async function perform(id, action, value) {
      const el = byId(id);
      if (!el) return { ok: false, error: `Element ${id} is no longer on the page.` };
      if (el.disabled || el.getAttribute("aria-disabled") === "true") return { ok: false, error: "That control is disabled." };
      switch (action) {
        case "click": {
          el.focus?.({ preventScroll: true });
          mouse(el, "pointerdown");
          mouse(el, "mousedown");
          mouse(el, "pointerup");
          mouse(el, "mouseup");
          el.click();
          return { ok: true };
        }
        case "type": {
          if ((el.getAttribute("type") || "").toLowerCase() === "password") {
            return { ok: false, error: "Instruction Maker never types passwords." };
          }
          el.focus?.({ preventScroll: true });
          if (el.isContentEditable) {
            document.execCommand("selectAll");
            document.execCommand("insertText", false, value || "");
          } else if (el.tagName === "INPUT" || el.tagName === "TEXTAREA") {
            setNativeValue(el, value || "");
          } else {
            return { ok: false, error: "That element is not a text field." };
          }
          return { ok: true };
        }
        case "select": {
          if (el.tagName !== "SELECT") return { ok: false, error: "That element is not a dropdown; click it instead." };
          const want = (value || "").toLowerCase();
          const opt = [...el.options].find((o) => o.text.trim().toLowerCase() === want || o.value.toLowerCase() === want) || [...el.options].find((o) => o.text.toLowerCase().includes(want));
          if (!opt) return { ok: false, error: `No option "${value}" in that dropdown.` };
          el.value = opt.value;
          el.dispatchEvent(new Event("input", { bubbles: true }));
          el.dispatchEvent(new Event("change", { bubbles: true }));
          return { ok: true };
        }
        case "scroll_to": {
          el.scrollIntoView({ block: "center", behavior: "instant" });
          return { ok: true };
        }
        default:
          return { ok: false, error: `Unknown action ${action}` };
      }
    }
    function waitForSettle(quietMs = 450, maxMs = 6e3) {
      return new Promise((resolve) => {
        let timer = setTimeout(done, quietMs);
        const hard = setTimeout(done, maxMs);
        const obs = new MutationObserver(() => {
          clearTimeout(timer);
          timer = setTimeout(done, quietMs);
        });
        obs.observe(document.documentElement, { subtree: true, childList: true, attributes: true, characterData: true });
        function done() {
          obs.disconnect();
          clearTimeout(timer);
          clearTimeout(hard);
          resolve({ ok: true, url: location.href });
        }
      });
    }
    function frameStats() {
      let interactive = 0;
      for (const el of document.querySelectorAll(INTERACTIVE_SELECTOR)) {
        if (isVisible(el) && inViewport(el.getBoundingClientRect())) interactive++;
      }
      const iframes = [...document.querySelectorAll("iframe,frame")].filter((f) => isVisible(f)).map((f) => {
        const r = f.getBoundingClientRect();
        const cs = getComputedStyle(f);
        const left = r.left + f.clientLeft + parseFloat(cs.paddingLeft || 0);
        const top = r.top + f.clientTop + parseFloat(cs.paddingTop || 0);
        return { x: left, y: top, w: f.clientWidth - parseFloat(cs.paddingLeft || 0) - parseFloat(cs.paddingRight || 0), h: f.clientHeight - parseFloat(cs.paddingTop || 0) - parseFloat(cs.paddingBottom || 0) };
      });
      return { interactive, textLength: (document.body?.innerText || "").length, w: window.innerWidth, h: window.innerHeight, dpr: window.devicePixelRatio || 1, url: location.href, iframes };
    }
    const MAP_BLUR_CSS = `
    .leaflet-tile-pane, img.leaflet-tile,
    .gm-style img[src*="/vt"], .gm-style img[src*="khms"], .gm-style img[src*="/kh"], .gm-style canvas,
    .mapboxgl-canvas, .maplibregl-canvas, .ol-layer canvas, [data-map-tiles] { filter: blur(9px) !important; }`;
    async function setMapBlur(on) {
      let tag = document.getElementById("__im_mapblur");
      if (on && !tag) {
        tag = document.createElement("style");
        tag.id = "__im_mapblur";
        tag.textContent = MAP_BLUR_CSS;
        (document.head || document.documentElement).appendChild(tag);
        await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
      } else if (!on && tag) {
        tag.remove();
      }
      return { ok: true, maps: document.querySelectorAll(".leaflet-container,.gm-style,.mapboxgl-map,.maplibregl-map,.ol-viewport").length };
    }
    window.__IM = { version: VERSION, collectPage, listTextCandidates, computeRedactions, applyFakes, restoreFakes, prepare, geometry, perform, waitForSettle, frameStats, setMapBlur };
  })();
})();
