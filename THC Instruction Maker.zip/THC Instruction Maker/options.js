(() => {
  // src/lib/google.js
  var DEFAULT_FOLDERS = {
    root: "Instruction Guides",
    admin: "Admin Guides",
    caregiver: "Caregiver Guides",
    client: "Client Guides"
  };

  // src/lib/settings.js
  var DEFAULT_SETTINGS = {
    apiKey: "",
    apiBaseUrl: "",
    theme: "light",
    // 'light' | 'dark' | 'auto' (match the computer)
    planner: "auto",
    // 'auto' = free first, Claude only when that fails; 'rules' = free only; 'claude' = Claude every step
    privacyStyle: "fake",
    // 'fake' = swap in obvious sample data, 'black' = black boxes
    aiRedaction: true,
    autoDrive: true,
    // save to Google Drive and show the links as soon as a run finishes
    blurMaps: true,
    // blur map streets and satellite photos in screenshots
    hideDates: false,
    hideAllFieldValues: false,
    cropMode: "smart",
    // 'smart' = area around the button, 'full' = whole visible screen
    extraRiskyWords: "",
    folders: { ...DEFAULT_FOLDERS }
  };
  async function loadSettings() {
    const { settings } = await chrome.storage.local.get("settings");
    return { ...DEFAULT_SETTINGS, ...settings || {}, folders: { ...DEFAULT_FOLDERS, ...settings?.folders || {} } };
  }
  async function saveSettings(settings) {
    await chrome.storage.local.set({ settings });
  }
  async function applyTheme() {
    const { theme } = await loadSettings();
    document.documentElement.dataset.theme = theme || "light";
  }

  // src/options.js
  var $ = (id) => document.getElementById(id);
  var TEXT = ["apiKey", "apiBaseUrl", "extraRiskyWords", "cropMode", "privacyStyle", "theme", "planner"];
  var CHECKS = ["aiRedaction", "autoDrive", "blurMaps", "hideDates", "hideAllFieldValues"];
  var FOLDERS = ["root", "admin", "caregiver", "client"];
  async function init() {
    const s = await loadSettings();
    TEXT.forEach((k) => {
      $(k).value = s[k] || "";
    });
    CHECKS.forEach((k) => {
      $(k).checked = !!s[k];
    });
    FOLDERS.forEach((k) => {
      $("f_" + k).value = s.folders[k] || "";
    });
  }
  $("save").onclick = async () => {
    const s = await loadSettings();
    TEXT.forEach((k) => {
      s[k] = $(k).value.trim();
    });
    CHECKS.forEach((k) => {
      s[k] = $(k).checked;
    });
    FOLDERS.forEach((k) => {
      s.folders[k] = $("f_" + k).value.trim() || s.folders[k];
    });
    await saveSettings(s);
    await applyTheme();
    $("saved").textContent = "Saved.";
    setTimeout(() => {
      $("saved").textContent = "";
    }, 2e3);
  };
  applyTheme();
  init();
})();
