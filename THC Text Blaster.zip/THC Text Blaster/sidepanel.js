/* THC Text Blaster — side panel.
 *
 * This file is the whole UI *and* the send loop. The loop lives here (not in the
 * service worker and not in a popup) for one reason: Chrome tears down an action
 * popup the moment it loses focus, and a service worker can be evicted while
 * idle. The side panel stays alive while you click around Google Voice, so a
 * blast survives you looking at the page it is driving.
 *
 * Split of responsibilities:
 *   - here:        who to send to, what to send, pacing, logging, stop control
 *   - content.js:  the Google Voice DOM steps for ONE message
 *   - Code.gs:     the Contacts tab and the Message Log tab
 *
 * The pure logic at the top has no DOM/chrome dependencies and is exported for
 * `npm test` (see tests/logic.test.js). Nothing outside `boot()` touches the DOM
 * or the chrome.* APIs, so requiring this file in Node is safe.
 */

'use strict';

/* ============================================================================
 * Pure logic (unit-tested)
 * ========================================================================== */

/** The groups we know about, in display order. Ones the sheet has no rows for yet
 *  render as disabled "none yet" buttons — they light up once someone is added. */
// `section` groups the buttons under a heading (THC Text Blaster shows one
// button grid per section) — kept in this order, top to bottom.
const CANONICAL_GROUPS = [
  { key: 'thc-staff', label: 'THC Staff', button: 'THC Staff', section: 'THC Company' },
  { key: 'rceb-cg', label: 'RCEB · Caregiver', button: 'RCEB Caregivers', section: 'RCEB' },
  { key: 'rceb-cl', label: 'RCEB · Client', button: 'RCEB Clients', section: 'RCEB' },
  { key: 'rceb-cd', label: 'RCEB · Candidate', button: 'RCEB Candidates', section: 'RCEB' },
  { key: 'ggrc-cg', label: 'GGRC · Caregiver', button: 'GGRC Caregivers', section: 'GGRC' },
  { key: 'ggrc-cl', label: 'GGRC · Client', button: 'GGRC Clients', section: 'GGRC' },
  { key: 'ggrc-cd', label: 'GGRC · Candidate', button: 'GGRC Candidates', section: 'GGRC' },
  { key: 'sarc-cg', label: 'SARC · Caregiver', button: 'SARC Caregivers', section: 'SARC' },
  { key: 'sarc-cl', label: 'SARC · Client', button: 'SARC Clients', section: 'SARC' }
];

/** Groups offered as "Belongs to" tick boxes when adding a contact. SARC is left
 *  off until the agency actually uses it — drop the filter to bring it back. */
const ADD_GROUP_OPTIONS = CANONICAL_GROUPS.filter((g) => !g.key.startsWith('sarc-'));

/** Rough seconds one send takes inside Google Voice (open → type → send). Only
 *  used for the "this will take about N" estimate on the review step. */
const SECONDS_PER_SEND = 6;

/** Phone → digits only, for handing to Google Voice. Drops a leading US 1. */
function normalizePhone(v) {
  let digits = String(v == null ? '' : v).replace(/\D/g, '');
  if (digits.length === 11 && digits.charAt(0) === '1') digits = digits.slice(1);
  return digits;
}

/** Phone → "(510) 555-1234" for display. Mirrors formatPhone in Code.gs so a
 *  number typed into the sheet in any format still looks right in the panel. */
function formatPhone(v) {
  const digits = normalizePhone(v);
  if (digits.length !== 10) return String(v == null ? '' : v).trim();
  return '(' + digits.slice(0, 3) + ') ' + digits.slice(3, 6) + '-' + digits.slice(6);
}

/** "Maria Santos" -> "Maria" */
function firstNameOf(name) {
  return String(name == null ? '' : name).trim().split(/\s+/)[0] || '';
}

// Tolerates {FirstName}, {firstname}, { Name } — people retype these by hand.
const PLACEHOLDER_RE = /\{\s*(firstname|name)\s*\}/gi;

/**
 * Returns the per-recipient renderer for a compose mode.
 *   'personalized' -> substitutes {FirstName} / {Name}
 *   anything else  -> identical: the template is sent verbatim, braces and all
 * Kept as a factory so the mode is resolved once per blast, not per recipient.
 */
function renderMessageForFactory(mode) {
  if (mode !== 'personalized') {
    return (template) => String(template == null ? '' : template);
  }
  return (template, person) =>
    String(template == null ? '' : template).replace(PLACEHOLDER_RE, (_match, key) =>
      key.toLowerCase() === 'firstname'
        // Prefer the sheet's own FirstName column; splitting a full name is the
        // fallback and gets names like "Mary Ann Cruz" wrong.
        ? String((person && person.first) || firstNameOf(person && person.name))
        : String((person && person.name) || '')
    );
}

/** Does this body actually use a placeholder? Drives a review-step warning. */
function hasPlaceholder(template) {
  PLACEHOLDER_RE.lastIndex = 0;
  return PLACEHOLDER_RE.test(String(template == null ? '' : template));
}

/** Unique {key,label} groups present in a contact list, in order of appearance.
 *  Fallback for a backend that didn't send a `groups` array. */
function deriveGroups(people) {
  const seen = new Map();
  (people || []).forEach((p) => {
    if (p && p.group && !seen.has(p.group)) seen.set(p.group, p.groupLabel || p.group);
  });
  return Array.from(seen, ([key, label]) => ({ key, label }));
}

/** Identity for selection/dedupe: same number + same name = same person. */
function contactKey(c) {
  return normalizePhone(c && c.phone) + '|' + String((c && c.name) || '').trim().toLowerCase();
}

/** Wall-clock estimate for a run, in seconds. */
function estimateRunSeconds(count, minDelay, maxDelay) {
  const n = Number(count) || 0;
  if (n <= 0) return 0;
  const avgDelay = ((Number(minDelay) || 0) + (Number(maxDelay) || 0)) / 2;
  return Math.round(n * SECONDS_PER_SEND + Math.max(0, n - 1) * avgDelay);
}

/** 95 -> "about 2 min", 3700 -> "about 1 hr 2 min" */
function formatDuration(seconds) {
  const s = Math.max(0, Math.round(Number(seconds) || 0));
  if (s < 60) return 'about ' + s + ' sec';
  const m = Math.round(s / 60);
  if (m < 60) return 'about ' + m + ' min';
  const h = Math.floor(m / 60);
  const rem = m % 60;
  return 'about ' + h + ' hr' + (rem ? ' ' + rem + ' min' : '');
}

/** Case/space-insensitive name (or number) match for the search dropdown. */
function matchesQuery(contact, query) {
  const q = String(query || '').trim().toLowerCase();
  if (!q) return false;
  if (String(contact.name || '').toLowerCase().includes(q)) return true;
  const qDigits = q.replace(/\D/g, '');
  return qDigits.length >= 3 && normalizePhone(contact.phone).includes(qDigits);
}

/**
 * Plans a blast: applies the send order, flags numbers that can't be sent, and
 * marks repeats so the loop skips them instead of texting someone twice.
 * Pure so the review step and the send loop agree on what will happen.
 */
function planRun(recipients) {
  const seen = new Set();
  return (recipients || []).map((c) => {
    const digits = normalizePhone(c.phone);
    let skip = '';
    if (digits.length !== 10) skip = 'unusable number';
    else if (seen.has(digits)) skip = 'duplicate number in this blast';
    else seen.add(digits);
    return { contact: c, digits, skip };
  });
}

/**
 * Checks a new contact before it's sent to the sheet. Returns {ok:true} or
 * {ok:false, error} with wording meant to be shown to the person typing.
 */
function validateNewContact(c) {
  const first = String((c && c.first) || '').trim();
  const last = String((c && c.last) || '').trim();
  const digits = normalizePhone(c && c.phone);
  const groups = (c && c.groups) || [];

  if (!first && !last) return { ok: false, error: 'Type at least a first or last name.' };
  if (!digits) return { ok: false, error: 'Type a phone number.' };
  if (digits.length !== 10) {
    return { ok: false, error: 'That phone number has ' + digits.length + ' digits — it needs 10.' };
  }
  if (!groups.length) return { ok: false, error: 'Tick at least one group under "Belongs to".' };
  return { ok: true };
}

/**
 * Work email -> a readable name for the Message Log's Sender column.
 * "jexter@togetherhomecare.org" -> "Jexter"; "mary.ann@..." -> "Mary Ann".
 * Falls back to the email itself if it doesn't look like one.
 */
function nameFromEmail(email) {
  const local = String(email == null ? '' : email).trim().split('@')[0];
  if (!local) return '';
  return local
    .split(/[._-]+/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1).toLowerCase())
    .join(' ');
}

/** Insert text at the cursor of a textarea, replacing any selection. */
function insertAtCursor(textarea, text) {
  const start = textarea.selectionStart == null ? textarea.value.length : textarea.selectionStart;
  const end = textarea.selectionEnd == null ? textarea.value.length : textarea.selectionEnd;
  const before = textarea.value.slice(0, start);
  const after = textarea.value.slice(end);
  const value = before + text + after;
  const caret = start + text.length;
  return { value, caret };
}

/** Sortable, human-readable batch id: THC-20260812-1734-a9f */
function makeBatchId(now, rand) {
  const d = now || new Date();
  const p = (n) => String(n).padStart(2, '0');
  const stamp =
    d.getFullYear() + p(d.getMonth() + 1) + p(d.getDate()) + '-' + p(d.getHours()) + p(d.getMinutes());
  const suffix = (rand == null ? Math.random() : rand).toString(36).slice(2, 5);
  return 'THC-' + stamp + '-' + suffix;
}

/* ============================================================================
 * UI + send loop (browser only)
 * ========================================================================== */

/**
 * Together Homecare's deployed Apps Script web app, pre-filled so the panel
 * works the moment it's installed — no pasting a URL after every reinstall.
 * The gear still overrides it, and anything saved there wins.
 *
 * This URL is effectively a key to the Sheet: anyone holding it can read every
 * contact (names and phone numbers) and append rows. Keep this repository
 * private, and re-deploy to a new URL if it ever leaks.
 */
const DEFAULT_WEB_APP_URL =
  'https://script.google.com/macros/s/AKfycbzbsAamubEDrLVg5iYuOfKQ-iRkgrwuJf--bHdGW6Hegy9txLerWfSHGlr_kwcad00d/exec';

const DEFAULTS = { delayMin: 4, delayMax: 8, mode: 'identical', message: '' };
const STORAGE_KEY = 'thcBlaster';

const state = {
  webAppUrl: '',
  contacts: [],
  groups: [],
  activeGroup: null,
  selected: new Map(),
  mode: DEFAULTS.mode,
  running: false,
  stopRequested: false,
  pendingLogs: [],
  logRows: 0,
  senderName: '',
  editingPhone: ''
};

const el = {};
const $ = (id) => document.getElementById(id);

function boot() {
  [
    'settingsBtn', 'settingsPane', 'senderNameInput', 'webAppUrl', 'saveSettingsBtn', 'closeSettingsBtn',
    'captureBtn', 'probeBtn', 'settingsStatus', 'mainPane', 'search', 'dropdown', 'groups', 'selall',
    'selallCb', 'selallLabel', 'contacts', 'selCount', 'chips', 'modeIdentical',
    'modePersonalized', 'message', 'persHint', 'charCount', 'delayMin', 'delayMax',
    'reviewBtn', 'reviewPane', 'log', 'clearAllBtn',
    'addContactBtn', 'addPane', 'newFirst', 'newLast', 'newPhone', 'newGroups',
    'saveContactBtn', 'closeAddBtn', 'addStatus',
    'editContactBtn', 'editSearch', 'editDropdown',
    'editPane', 'editFirst', 'editLast', 'editPhone', 'editGroups',
    'saveEditBtn', 'closeEditBtn', 'editStatus',
    'insertRow', 'insertFirst', 'insertFull'
  ].forEach((id) => { el[id] = $(id); });

  wireEvents();
  restore().then(async () => {
    await detectSenderFromAccount();
    loadSenderName();
  });
}

/**
 * Who is sending this blast — read from the signed-in Chrome profile, not
 * typed. Everyone works remotely on their own machine signed into their own
 * work account, so this identifies the sender without a login screen or a
 * name that could be mistyped or left as someone else's. Only reaches the
 * Message Log; nothing else in the panel depends on it.
 */
/**
 * Identifies the sender from the Google Voice account itself, rather than
 * asking Chrome who's signed in: Google Voice always shows "Call as
 * (510) 214-3084" in its calling panel, and that number is the same one
 * everyone already has listed for themselves in the Contacts sheet — so
 * matching it against the loaded contacts gives the REAL name, grounded in
 * the same sheet everyone already trusts.
 *
 * This exists because the Chrome-account approach (loadSenderName, below)
 * turned out not to work at all for a real signed-in account — it isn't a
 * theory this time, it's confirmed. Runs fresh at the start of every batch
 * (not just once at boot), since whoever is signed into Google Voice can
 * change between sessions and the log should reflect who is ACTUALLY sending
 * this particular blast. Best-effort throughout: no Google Voice tab yet, no
 * "Call as" text found, or a number that isn't in anyone's contact record all
 * just leave state.senderName as it was — the typed name in Settings (or
 * nothing) remains the fallback.
 */
async function detectSenderFromAccount(tabId) {
  try {
    let id = tabId;
    if (id == null) {
      const tabs = await chrome.tabs.query({ url: 'https://voice.google.com/*' });
      if (!tabs.length) return;
      id = tabs[0].id;
    }
    const res = await messageTab(id, { type: 'THC_ACCOUNT_NUMBER' });
    if (!res || !res.digits) return;
    const match = state.contacts.find((c) => normalizePhone(c.phone) === res.digits);
    if (!match) return;
    state.senderName = match.name;
    el.senderNameInput.value = match.name;
    persist();
  } catch (_) { /* best-effort only */ }
}

/**
 * One-time best-effort pre-fill: if nobody has typed a name yet AND the
 * Google Voice account match above didn't find anything, try reading the
 * signed-in Chrome profile's email as a last-resort starting guess. Only ever
 * runs when state.senderName is still empty, and never overwrites a name
 * that's already saved.
 *
 * Kept as a third fallback layer even though it failed for a real account
 * once already — it costs nothing to try, and might work for a different
 * setup. In practice it can come back empty depending on things outside this
 * extension's control (Chrome Sync being on, a Workspace admin's policies on
 * what extensions may read). When everything fails, the field stays blank and
 * the Review step says so.
 */
function loadSenderName() {
  if (state.senderName) return;
  try {
    chrome.identity.getProfileUserInfo({ accountStatus: 'ANY' }, (info) => {
      if (state.senderName) return; // something else already filled it in
      const guess = nameFromEmail(info && info.email) || (info && info.email) || '';
      if (!guess) return;
      state.senderName = guess;
      el.senderNameInput.value = guess;
      persist();
    });
  } catch (_) { /* leave it blank; the review-step nudge covers this */ }
}

function wireEvents() {
  el.settingsBtn.addEventListener('click', () => showPane(el.settingsPane.hidden ? 'settings' : 'main'));
  el.closeSettingsBtn.addEventListener('click', () => showPane('main'));
  el.saveSettingsBtn.addEventListener('click', saveSettings);
  el.senderNameInput.addEventListener('input', () => {
    state.senderName = el.senderNameInput.value.trim();
    persist();
  });
  if (el.captureBtn) el.captureBtn.addEventListener('click', captureGoogleVoice);
  if (el.probeBtn) el.probeBtn.addEventListener('click', probeRecipientRow);

  el.addContactBtn.addEventListener('click', openAddContact);
  el.editContactBtn.addEventListener('click', openEditPane);
  el.editSearch.addEventListener('input', () => renderEditDropdown());
  el.editSearch.addEventListener('focus', () => renderEditDropdown());
  el.closeAddBtn.addEventListener('click', () => showPane('main'));
  el.saveContactBtn.addEventListener('click', submitNewContact);
  el.closeEditBtn.addEventListener('click', () => showPane('main'));
  el.saveEditBtn.addEventListener('click', submitEditContact);
  // Enter anywhere in the form submits, like any other small form.
  [el.newFirst, el.newLast, el.newPhone].forEach((input) =>
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') submitNewContact(); }));

  el.search.addEventListener('input', () => renderDropdown());
  el.search.addEventListener('focus', () => renderDropdown());
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.search-wrap')) { hideDropdown(); hideEditDropdown(); }
  });

  el.selallCb.addEventListener('change', () => {
    const rows = visibleContacts();
    rows.forEach((c) => {
      if (el.selallCb.checked) state.selected.set(contactKey(c), c);
      else state.selected.delete(contactKey(c));
    });
    renderContacts();
    renderChips();
  });

  el.modeIdentical.addEventListener('click', () => setMode('identical'));
  el.modePersonalized.addEventListener('click', () => setMode('personalized'));
  el.insertFirst.addEventListener('click', () => insertPlaceholder('{FirstName}'));
  el.insertFull.addEventListener('click', () => insertPlaceholder('{Name}'));

  el.message.addEventListener('input', () => {
    el.charCount.textContent = String(el.message.value.length);
    persist();
  });
  [el.delayMin, el.delayMax].forEach((input) => input.addEventListener('change', persist));

  el.clearAllBtn.addEventListener('click', () => {
    state.selected.clear();
    renderChips();
    renderContacts();
  });

  el.reviewBtn.addEventListener('click', renderReview);
}

/* ---------- persistence ---------- */

async function restore() {
  let saved = {};
  try {
    const bag = await chrome.storage.local.get(STORAGE_KEY);
    saved = bag[STORAGE_KEY] || {};
  } catch (_) { /* first run */ }

  state.webAppUrl = saved.webAppUrl || DEFAULT_WEB_APP_URL;
  state.contacts = saved.contacts || [];
  state.groups = saved.groups && saved.groups.length ? saved.groups : deriveGroups(state.contacts);
  state.mode = saved.mode === 'personalized' ? 'personalized' : 'identical';
  state.senderName = saved.senderName || '';
  focusSingleGroup();

  el.senderNameInput.value = state.senderName;
  el.webAppUrl.value = state.webAppUrl;
  el.message.value = saved.message || DEFAULTS.message;
  el.charCount.textContent = String(el.message.value.length);
  el.delayMin.value = saved.delayMin || DEFAULTS.delayMin;
  el.delayMax.value = saved.delayMax || DEFAULTS.delayMax;

  setMode(state.mode);
  renderAll();

  if (!state.webAppUrl) {
    showPane('settings');
    setStatus('Paste the Apps Script Web App URL to load contacts.', '');
  } else {
    // Cached contacts render instantly; refresh quietly in the background.
    persist();                       // remember the built-in URL as the saved one
    refreshContacts({ quiet: true });
  }
}

function persist() {
  const payload = {
    webAppUrl: state.webAppUrl,
    senderName: state.senderName,
    contacts: state.contacts,
    groups: state.groups,
    mode: state.mode,
    message: el.message.value,
    delayMin: Number(el.delayMin.value) || DEFAULTS.delayMin,
    delayMax: Number(el.delayMax.value) || DEFAULTS.delayMax
  };
  try {
    chrome.storage.local.set({ [STORAGE_KEY]: payload });
  } catch (_) { /* non-fatal */ }
}

/* ---------- settings ---------- */

/** Only one of the three panes is on screen at a time. */
function showPane(which) {
  el.settingsPane.hidden = which !== 'settings';
  el.addPane.hidden = which !== 'add';
  el.editPane.hidden = which !== 'edit';
  el.mainPane.hidden = which === 'settings' || which === 'add' || which === 'edit';
}

function setStatus(text, kind) {
  el.settingsStatus.textContent = text;
  el.settingsStatus.style.color = kind === 'err' ? 'var(--err)' : kind === 'ok' ? 'var(--ok)' : '';
}

async function saveSettings() {
  const url = el.webAppUrl.value.trim();
  if (!/^https:\/\/script\.google(usercontent)?\.com\/.+/.test(url)) {
    setStatus('That does not look like a Web App /exec URL.', 'err');
    return;
  }
  if (!/\/exec(\?|$)/.test(url)) {
    setStatus('Use the /exec URL from Deploy → Manage deployments (not /dev).', 'err');
    return;
  }
  state.webAppUrl = url;
  persist();
  setStatus('Loading contacts…', '');
  const ok = await refreshContacts({});
  if (ok) setTimeout(() => showPane('main'), 600);
}

/** GET ?action=contacts. Returns true on success. */
async function refreshContacts({ quiet }) {
  if (!state.webAppUrl) return false;
  const url = state.webAppUrl + (state.webAppUrl.includes('?') ? '&' : '?') + 'action=contacts';
  try {
    const res = await fetch(url, { method: 'GET', redirect: 'follow' });
    const data = await res.json();
    if (!data || !data.ok) throw new Error((data && data.error) || 'the script returned an error');

    state.contacts = (data.contacts || []).map((c) => ({
      name: String(c.name || '').trim(),
      first: String(c.first || '').trim() || firstNameOf(c.name),
      last: String(c.last || '').trim(),
      phone: formatPhone(c.phone),
      group: c.group || '',
      groupLabel: c.groupLabel || ''
    }));
    state.groups = data.groups && data.groups.length ? data.groups : deriveGroups(state.contacts);
    focusSingleGroup();

    // Drop selections for people no longer in the sheet.
    const live = new Set(state.contacts.map(contactKey));
    Array.from(state.selected.keys()).forEach((k) => { if (!live.has(k)) state.selected.delete(k); });

    persist();
    renderAll();
    setStatus(
      'Loaded ' + state.contacts.length + ' contacts from ' +
      ((data.tabs_read && data.tabs_read.length) ? data.tabs_read.join(', ') : 'the sheet') +
      (data.script_version ? ' (script v' + data.script_version + ').' : '.'),
      'ok'
    );
    return true;
  } catch (err) {
    const msg = 'Could not load contacts: ' + (err && err.message ? err.message : err);
    if (quiet) console.warn('[THC]', msg);
    else setStatus(msg + ' Check the deployment is published and open to "Anyone with the link".', 'err');
    return false;
  }
}

/** Ctrl+Shift+G equivalent, driven from the panel. */
async function captureGoogleVoice() {
  setStatus('Asking the Google Voice tab for a capture…', '');
  try {
    const tabId = await findVoiceTab();
    const cap = await messageTab(tabId, { type: 'THC_CAPTURE' });
    if (!cap || !cap.ok) throw new Error('no response from the page');
    console.log('=== THC Text Blaster — Google Voice interface capture ===');
    console.log(cap.capture);
    const missing = Object.entries(cap.capture.found || {})
      .filter(([, hit]) => !hit)
      .map(([name]) => name);
    setStatus(
      missing.length
        ? 'Capture logged to this panel\'s console. Selectors that did NOT match: ' + missing.join(', ')
        : 'Capture logged to this panel\'s console. Every selector matched.',
      missing.length ? 'err' : 'ok'
    );
  } catch (err) {
    setStatus('Capture failed: ' + (err && err.message ? err.message : err), 'err');
  }
}

/* ---------- shared "Belongs to" checklist (add + edit) ---------- */

/**
 * Renders the group tick-list into any container, section headings and all —
 * same layout the recipient grid uses, so Add and Edit contact both read the
 * same way. `preTicked`, when given, overrides whatever was already ticked
 * (used to open the Edit pane pre-filled with a person's current groups);
 * otherwise re-rendering (e.g. after a save) preserves what's already ticked.
 */
function renderGroupChecklist(container, preTicked) {
  const ticked = preTicked || new Set(checkedGroupsIn(container));
  container.textContent = '';

  let section = null;
  ADD_GROUP_OPTIONS.forEach((g) => {
    if (g.section !== section) {
      section = g.section;
      const heading = document.createElement('div');
      heading.className = 'check-section-label';
      heading.textContent = section;
      container.appendChild(heading);
    }

    const n = countIn(g.key);
    const row = document.createElement('label');
    row.className = 'check-row';

    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.value = g.key;
    cb.dataset.group = g.key;
    cb.checked = ticked.has(g.key);

    const text = document.createElement('span');
    text.textContent = g.label;

    const count = document.createElement('span');
    count.className = 'count';
    count.textContent = n ? n + ' now' : 'empty';

    row.appendChild(cb);
    row.appendChild(text);
    row.appendChild(count);
    container.appendChild(row);
  });
}

function checkedGroupsIn(container) {
  return Array.from(container.querySelectorAll('input:checked')).map((cb) => cb.dataset.group);
}

/* ---------- adding a contact ---------- */

function openAddContact() {
  renderGroupChecklist(el.newGroups);
  setAddStatus('', '');
  showPane('add');
  el.newFirst.focus();
}

function checkedGroups() {
  return checkedGroupsIn(el.newGroups);
}

function setAddStatus(text, kind) {
  el.addStatus.textContent = text;
  el.addStatus.style.color = kind === 'err' ? 'var(--err)' : kind === 'ok' ? 'var(--ok)' : '';
}

async function submitNewContact() {
  if (!state.webAppUrl) {
    setAddStatus('Save your Web App URL under the gear first — that\'s where the contact gets written.', 'err');
    return;
  }

  const contact = {
    first: el.newFirst.value.trim(),
    last: el.newLast.value.trim(),
    phone: el.newPhone.value.trim(),
    groups: checkedGroups()
  };

  const check = validateNewContact(contact);
  if (!check.ok) {
    setAddStatus(check.error, 'err');
    return;
  }

  el.saveContactBtn.disabled = true;
  setAddStatus('Adding to the sheet…', '');
  try {
    const res = await fetch(state.webAppUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ action: 'addContact', contact }),
      redirect: 'follow'
    });
    const data = await res.json();
    if (!data || !data.ok) throw new Error((data && data.error) || 'the script rejected it');

    const parts = [];
    if (data.added && data.added.length) parts.push('added to ' + data.added.join(', '));
    if (data.already && data.already.length) parts.push('already in ' + data.already.join(', '));
    setAddStatus(
      (data.name || 'Contact') + ' — ' + (parts.join('; ') || 'nothing to do') + '.',
      (data.added && data.added.length) ? 'ok' : 'err'
    );

    // Clear the name and number but keep the ticks: adding a household or a run
    // of people into the same group is the common case.
    el.newFirst.value = '';
    el.newLast.value = '';
    el.newPhone.value = '';
    el.newFirst.focus();

    await refreshContacts({ quiet: true });
    renderGroupChecklist(el.newGroups);
  } catch (err) {
    setAddStatus('Could not add: ' + (err && err.message ? err.message : err), 'err');
  } finally {
    el.saveContactBtn.disabled = false;
  }
}

/* ---------- editing a contact ---------- */

/**
 * "Edit contact" opens its own pane, blank, with a search box — deliberately
 * separate from the recipient checkboxes in the main list. Tying editing to
 * "who's ticked for a blast" meant editing someone required first touching
 * their selection state, which had nothing to do with editing them.
 */
function openEditPane() {
  el.editSearch.value = '';
  hideEditDropdown();
  el.editFirst.value = '';
  el.editLast.value = '';
  el.editPhone.value = '';
  renderGroupChecklist(el.editGroups, new Set());
  state.editingPhone = '';
  setEditStatus('', '');
  showPane('edit');
  el.editSearch.focus();
}

function renderEditDropdown() {
  const q = el.editSearch.value.trim();
  if (!q) return hideEditDropdown();

  const hits = state.contacts
    .filter((c) => matchesQuery(c, q))
    .sort((a, b) => a.name.localeCompare(b.name))
    .slice(0, 40);

  el.editDropdown.textContent = '';
  if (!hits.length) {
    el.editDropdown.innerHTML = '<div class="empty">No match for “' + escapeHtml(q) + '”</div>';
  } else {
    hits.forEach((c) => {
      const row = pickableContactRow(c);
      row.addEventListener('click', () => {
        el.editSearch.value = '';
        hideEditDropdown();
        openEditContact(c);
      });
      el.editDropdown.appendChild(row);
    });
  }
  el.editDropdown.hidden = false;
}

function hideEditDropdown() {
  el.editDropdown.hidden = true;
  el.editDropdown.textContent = '';
}

/**
 * A plain, checkbox-free contact row for "pick one" contexts like this search
 * — reusing contactRow() here would put a blast-recipient checkbox in a list
 * meant only for choosing who to edit, which is exactly the mix-up this
 * redesign is meant to avoid.
 */
function pickableContactRow(c) {
  const row = document.createElement('div');
  row.className = 'contact-row';
  row.innerHTML =
    '<div class="contact-text">' +
      '<span class="contact-name">' + escapeHtml(c.name) + '</span>' +
      '<span class="contact-sub">' + escapeHtml(subline(c)) + '</span>' +
    '</div>';
  return row;
}

/**
 * Opens the Edit pane pre-filled for one person. A person can belong to more
 * than one group, and each is its own row/tab in the sheet (mirrors how Add a
 * contact writes them) — so their current groups are gathered by matching
 * every contact record against this same phone number, not read off the one
 * record that was clicked.
 */
function openEditContact(contact) {
  const digits = normalizePhone(contact.phone);
  const currentGroups = new Set(
    state.contacts.filter((c) => normalizePhone(c.phone) === digits).map((c) => c.group)
  );

  // The ORIGINAL number — kept even if the phone field below gets edited — is
  // how the save finds the right rows on the sheet again.
  state.editingPhone = digits;

  el.editFirst.value = contact.first || '';
  el.editLast.value = contact.last || '';
  el.editPhone.value = contact.phone;

  renderGroupChecklist(el.editGroups, currentGroups);
  setEditStatus('', '');
  showPane('edit');
  el.editFirst.focus();
}

function setEditStatus(text, kind) {
  el.editStatus.textContent = text;
  el.editStatus.style.color = kind === 'err' ? 'var(--err)' : kind === 'ok' ? 'var(--ok)' : '';
}

async function submitEditContact() {
  if (!state.webAppUrl) {
    setEditStatus('Save your Web App URL under the gear first.', 'err');
    return;
  }
  if (!state.editingPhone) {
    setEditStatus('Lost track of which contact this is — close and click Edit again.', 'err');
    return;
  }

  const contact = {
    first: el.editFirst.value.trim(),
    last: el.editLast.value.trim(),
    phone: el.editPhone.value.trim(),
    groups: checkedGroupsIn(el.editGroups)
  };

  const check = validateNewContact(contact);
  if (!check.ok) {
    setEditStatus(check.error, 'err');
    return;
  }

  el.saveEditBtn.disabled = true;
  setEditStatus('Saving changes…', '');
  try {
    const res = await fetch(state.webAppUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ action: 'updateContact', contact: { ...contact, originalPhone: state.editingPhone } }),
      redirect: 'follow'
    });
    const data = await res.json();
    if (!data || !data.ok) throw new Error((data && data.error) || 'the script rejected it');

    const parts = [];
    if (data.updated && data.updated.length) parts.push('updated in ' + data.updated.join(', '));
    if (data.added && data.added.length) parts.push('added to ' + data.added.join(', '));
    if (data.removed && data.removed.length) parts.push('removed from ' + data.removed.join(', '));
    setEditStatus((data.name || 'Contact') + ' — ' + (parts.join('; ') || 'no changes') + '.', 'ok');

    await refreshContacts({ quiet: true });
    setTimeout(() => showPane('main'), 700);
  } catch (err) {
    setEditStatus('Could not save: ' + (err && err.message ? err.message : err), 'err');
  } finally {
    el.saveEditBtn.disabled = false;
  }
}

/**
 * Types a recipient's number into Google Voice and reports what turned up, in
 * the panel where it can be screenshotted. Nothing is sent.
 */
async function probeRecipientRow() {
  const target = Array.from(state.selected.values())[0] || state.contacts[0];
  if (!target) {
    setStatus('Load contacts first, then tick the person to test.', 'err');
    return;
  }
  clearDiag();
  setStatus('Typing ' + target.phone + ' into Google Voice…', '');
  try {
    const tabId = await findVoiceTab();
    await focusVoiceTab(tabId);
    const digits = normalizePhone(target.phone);
    const res = await messageTab(tabId, { type: 'THC_PROBE', phone: digits, digits });
    if (!res || !res.ok) throw new Error((res && res.error) || 'no response from the page');

    const lines = [];
    lines.push('Tested: ' + target.name + '  ' + target.phone);
    lines.push('To field now reads: "' + res.toValue + '"');
    lines.push('Typed by: ' + res.typedBy + (res.typedOk ? '' : ' (REJECTED)') +
               ' · page focused: ' + (res.pageFocused ? 'yes' : 'no'));
    lines.push('Page: ' + res.elements + ' elements, ' + res.shadowHosts + ' shadow roots');
    lines.push('Would the send find a row? ' + (res.matched ? 'YES' : 'NO'));
    lines.push('');
    lines.push('-- things naming that number (' + res.naming.length + ') --');
    res.naming.forEach((e) => lines.push(describeNode(e)));
    lines.push('');
    lines.push('-- things under the To field (' + res.below.length + ') --');
    res.below.forEach((e) => lines.push(describeNode(e)));

    showDiag(lines.join('\n'));
    setStatus(res.matched
      ? 'A matching row was found — sending should work.'
      : 'No matching row found. The dump below shows what is on screen.',
      res.matched ? 'ok' : 'err');
  } catch (err) {
    setStatus('Test failed: ' + (err && err.message ? err.message : err), 'err');
  }
}

function describeNode(e) {
  const where = e.inShadow ? ' [shadow]' : '';
  const role = e.role ? ' role=' + e.role : '';
  const label = e.label ? ' label="' + e.label + '"' : '';
  return '  ' + e.tag + role + label + where + ' @' + e.left + ',' + e.top + '  "' + e.text + '"';
}

function showDiag(text) {
  clearDiag();
  const box = document.createElement('div');
  box.className = 'diag';
  box.id = 'diagBox';
  box.textContent = text;
  el.settingsStatus.parentNode.appendChild(box);
}

function clearDiag() {
  const old = document.getElementById('diagBox');
  if (old) old.remove();
}

/* ---------- rendering ---------- */

function renderAll() {
  renderGroups();
  renderContacts();
  renderChips();
}

function countIn(groupKey) {
  return state.contacts.filter((c) => c.group === groupKey).length;
}

/** With exactly one group there is nothing to choose between, so pre-select it —
 *  that also puts the "select all" checkbox on screen straight away. */
function focusSingleGroup() {
  const keys = state.groups.map((g) => g.key);
  if (state.groups.length === 1) state.activeGroup = keys[0];
  else if (state.activeGroup && !keys.includes(state.activeGroup)) state.activeGroup = null;
}

function renderGroups() {
  el.groups.textContent = '';
  const present = new Set(state.groups.map((g) => g.key));

  // Show the regional-centre grid (including "none yet" placeholders) only if
  // the sheet actually uses those groups. A sheet that groups some other way —
  // one tab per list, say — gets buttons for exactly what it has, not nine
  // placeholders for groups that were never part of how it's organised.
  const anyCanonical = CANONICAL_GROUPS.some((cg) => present.has(cg.key));
  const extras = state.groups.filter((g) => !CANONICAL_GROUPS.some((cg) => cg.key === g.key));
  const rows = (anyCanonical ? CANONICAL_GROUPS : [])
    // An empty group is only worth a button if you can put someone in it from the
    // add form. That keeps the grid matching the "Belongs to" list, and a group
    // outside that list (SARC today) still appears the moment it has people.
    .filter((cg) => present.has(cg.key) || ADD_GROUP_OPTIONS.some((o) => o.key === cg.key))
    .concat(extras.map((g) => ({ key: g.key, label: g.label, button: g.label, section: 'Other' })));

  // One heading per section (THC Company / RCEB / GGRC / …), in the order each
  // is first seen — CANONICAL_GROUPS already lists them in the wanted order, so
  // this doesn't need a separate sort.
  let section = null;
  let grid = null;
  rows.forEach((g) => {
    if (g.section !== section) {
      section = g.section;
      const heading = document.createElement('div');
      heading.className = 'group-section-label';
      heading.textContent = section;
      el.groups.appendChild(heading);
      grid = document.createElement('div');
      grid.className = 'group-grid';
      el.groups.appendChild(grid);
    }

    const n = countIn(g.key);
    const btn = document.createElement('button');
    if (!present.has(g.key) || n === 0) {
      btn.className = 'group-btn disabled';
      btn.disabled = true;
      btn.innerHTML = escapeHtml(g.button) + '<br><span class="muted">none yet</span>';
      btn.title = 'Nobody in ' + g.label + ' yet — use "+ Add a new contact"';
    } else {
      btn.className = 'group-btn' + (state.activeGroup === g.key ? ' active' : '');
      btn.innerHTML = escapeHtml(g.button) + '<br><span class="muted">' + n + '</span>';
      btn.addEventListener('click', () => {
        state.activeGroup = state.activeGroup === g.key ? null : g.key;
        renderGroups();
        renderContacts();
      });
    }
    grid.appendChild(btn);
  });
}

/** The contacts the list is currently showing (group filter applied). */
function visibleContacts() {
  const list = state.activeGroup
    ? state.contacts.filter((c) => c.group === state.activeGroup)
    : state.contacts;
  return list.slice().sort((a, b) => a.name.localeCompare(b.name));
}

function renderContacts() {
  const rows = visibleContacts();
  el.contacts.textContent = '';

  if (!state.contacts.length) {
    el.contacts.innerHTML = '<div class="empty">No contacts loaded.<br>Open ⚙ and save your Web App URL.</div>';
    el.selall.hidden = true;
    return;
  }
  if (!rows.length) {
    el.contacts.innerHTML = '<div class="empty">Nothing in this group yet.</div>';
    el.selall.hidden = true;
    return;
  }

  // "Select all" belongs to a group selection, per the recipient-picking flow.
  if (state.activeGroup) {
    const group = state.groups.find((g) => g.key === state.activeGroup);
    const chosen = rows.filter((c) => state.selected.has(contactKey(c))).length;
    el.selall.hidden = false;
    el.selallCb.checked = chosen === rows.length;
    el.selallCb.indeterminate = chosen > 0 && chosen < rows.length;
    el.selallLabel.textContent =
      'Select all ' + rows.length + ' · ' + ((group && group.label) || state.activeGroup);
  } else {
    el.selall.hidden = true;
  }

  rows.forEach((c) => el.contacts.appendChild(contactRow(c)));
}

function contactRow(c) {
  const key = contactKey(c);
  const row = document.createElement('label');
  row.className = 'contact-row';

  const cb = document.createElement('input');
  cb.type = 'checkbox';
  cb.checked = state.selected.has(key);
  cb.addEventListener('change', () => {
    if (cb.checked) state.selected.set(key, c);
    else state.selected.delete(key);
    renderChips();
    renderContacts();
  });

  const text = document.createElement('div');
  text.className = 'contact-text';
  text.innerHTML =
    '<span class="contact-name">' + escapeHtml(c.name) + '</span>' +
    '<span class="contact-sub">' + escapeHtml(subline(c)) + '</span>';

  row.appendChild(cb);
  row.appendChild(text);
  return row;
}

/** "GGRC · Caregiver · (510) 555-9082" */
function subline(c) {
  return [c.groupLabel || c.group, c.phone].filter(Boolean).join(' · ');
}

function renderChips() {
  el.selCount.textContent = String(state.selected.size);
  el.clearAllBtn.hidden = state.selected.size === 0;
  el.chips.textContent = '';

  if (!state.selected.size) {
    el.chips.innerHTML = '<span class="hint" style="margin:2px 4px">Nobody selected yet.</span>';
    return;
  }

  Array.from(state.selected.entries())
    .sort((a, b) => a[1].name.localeCompare(b[1].name))
    .forEach(([key, c]) => {
      const chip = document.createElement('span');
      chip.className = 'chip';
      chip.innerHTML = escapeHtml(c.name) + ' <span class="x" title="Remove">&times;</span>';
      chip.querySelector('.x').addEventListener('click', () => {
        state.selected.delete(key);
        renderChips();
        renderContacts();
      });
      el.chips.appendChild(chip);
    });
}

/* ---------- search dropdown ---------- */

function renderDropdown() {
  const q = el.search.value.trim();
  if (!q) return hideDropdown();

  const hits = state.contacts
    .filter((c) => matchesQuery(c, q))
    .sort((a, b) => a.name.localeCompare(b.name))
    .slice(0, 40);

  el.dropdown.textContent = '';
  if (!hits.length) {
    el.dropdown.innerHTML = '<div class="empty">No match for “' + escapeHtml(q) + '”</div>';
  } else {
    hits.forEach((c) => {
      const row = contactRow(c);
      // Selecting from search should feel like "add this person and move on".
      row.addEventListener('click', () => {
        setTimeout(() => {
          el.search.value = '';
          hideDropdown();
          el.search.focus();
        }, 0);
      });
      el.dropdown.appendChild(row);
    });
  }
  el.dropdown.hidden = false;
}

function hideDropdown() {
  el.dropdown.hidden = true;
  el.dropdown.textContent = '';
}

/* ---------- compose ---------- */

function setMode(mode) {
  state.mode = mode === 'personalized' ? 'personalized' : 'identical';
  el.modeIdentical.classList.toggle('active', state.mode === 'identical');
  el.modePersonalized.classList.toggle('active', state.mode === 'personalized');
  el.persHint.hidden = state.mode !== 'personalized';
  el.insertRow.hidden = state.mode !== 'personalized';
  persist();
}

/** Drops {FirstName} or {Name} at the cursor, only meaningful in Personalized mode. */
function insertPlaceholder(token) {
  const { value, caret } = insertAtCursor(el.message, token);
  el.message.value = value;
  el.message.focus();
  el.message.setSelectionRange(caret, caret);
  el.charCount.textContent = String(value.length);
  persist();
}

/* ---------- review + send ---------- */

function readDelays() {
  let min = Math.max(1, Number(el.delayMin.value) || DEFAULTS.delayMin);
  let max = Math.max(1, Number(el.delayMax.value) || DEFAULTS.delayMax);
  if (max < min) max = min;
  el.delayMin.value = min;
  el.delayMax.value = max;
  return { min, max };
}

function renderReview() {
  const recipients = Array.from(state.selected.values()).sort((a, b) => a.name.localeCompare(b.name));
  const template = el.message.value;
  const problems = [];
  if (!recipients.length) problems.push('Pick at least one recipient.');
  if (!template.trim()) problems.push('Type a message first.');

  el.reviewPane.hidden = false;

  if (problems.length) {
    el.reviewPane.innerHTML =
      '<h4>Not ready yet</h4>' +
      problems.map((p) => '<div class="review-line">• ' + escapeHtml(p) + '</div>').join('');
    return;
  }

  const { min, max } = readDelays();
  const plan = planRun(recipients);
  const sendable = plan.filter((p) => !p.skip);
  const skipped = plan.filter((p) => p.skip);
  const warnings = [];
  if (skipped.length) {
    warnings.push(skipped.length + ' will be skipped (' + skipped.map((p) => p.skip)
      .filter((v, i, a) => a.indexOf(v) === i).join(', ') + ')');
  }
  if (state.mode === 'personalized' && !hasPlaceholder(template)) {
    warnings.push('Personalized mode, but the body has no {FirstName} or {Name} — everyone gets the same text');
  }
  if (!state.senderName) {
    warnings.push('No name set in Settings — the Message Log\'s Sender column will be blank for this batch');
  }

  el.reviewPane.innerHTML =
    '<h4>Review &amp; send</h4>' +
    '<div class="review-line"><b>' + sendable.length + '</b> recipient' + (sendable.length === 1 ? '' : 's') + '</div>' +
    '<div class="review-line">Mode: <b>' + (state.mode === 'personalized' ? 'Personalized' : 'Identical') + '</b></div>' +
    '<div class="review-line">Pacing: ' + min + '–' + max + ' sec between sends</div>' +
    '<div class="review-line">Estimated run: <b>' +
      escapeHtml(formatDuration(estimateRunSeconds(sendable.length, min, max))) + '</b></div>' +
    warnings.map((w) => '<div class="review-line" style="color:var(--warn)">⚠ ' + escapeHtml(w) + '</div>').join('') +
    '<div class="review-line" style="color:var(--rose-hint)">Keep this panel open and don\'t touch the Google Voice tab while it runs.</div>' +
    '<div class="progress-track"><div class="progress-fill" id="progressFill"></div></div>' +
    '<div class="review-line" id="runStatus"></div>' +
    '<div class="review-actions">' +
      '<button class="btn-go" id="startBtn">Start sending</button>' +
      '<button class="btn-stop" id="backBtn">Back</button>' +
    '</div>';

  $('startBtn').addEventListener('click', () => startRun(plan, template, min, max));
  $('backBtn').addEventListener('click', () => { el.reviewPane.hidden = true; });
}

function setRunStatus(text) {
  const node = $('runStatus');
  if (node) node.textContent = text;
}

function setProgress(done, total) {
  const fill = $('progressFill');
  if (fill) fill.style.width = (total ? Math.round((done / total) * 100) : 0) + '%';
}

async function startRun(plan, template, minDelay, maxDelay) {
  if (state.running) return;
  state.running = true;
  state.stopRequested = false;
  el.reviewBtn.disabled = true;

  const actions = el.reviewPane.querySelector('.review-actions');
  actions.innerHTML = '<button class="btn-stop" id="stopBtn">Stop after this one</button>';
  $('stopBtn').addEventListener('click', () => {
    state.stopRequested = true;
    setRunStatus('Stopping after the current send…');
  });

  const batchId = makeBatchId();
  const render = renderMessageForFactory(state.mode);
  const sendable = plan.filter((p) => !p.skip);
  let done = 0;
  let sent = 0;
  let failed = 0;

  logLine('Batch ' + batchId + ' started · ' + sendable.length + ' to send', 'skip');

  let tabId;
  try {
    tabId = await findVoiceTab();
  } catch (err) {
    logLine(String(err && err.message ? err.message : err), 'fail');
    setRunStatus('Stopped before sending.');
    return finishRun();
  }

  // Fresh every batch: whoever is signed into Google Voice right now is who
  // this run's Message Log rows should credit, not whoever it was last time.
  await detectSenderFromAccount(tabId);

  // Skips are recorded first so the sheet explains why someone got nothing.
  for (const item of plan) {
    if (!item.skip) continue;
    logLine(item.contact.name + ' — skipped (' + item.skip + ')', 'skip');
    await postLog(entryFor(batchId, item.contact, 'Skipped', item.skip, ''));
  }

  for (let i = 0; i < sendable.length; i++) {
    if (state.stopRequested) {
      logLine('Stopped by you — ' + (sendable.length - i) + ' not sent', 'skip');
      break;
    }

    const { contact, digits } = sendable[i];
    const message = render(template, {
      name: contact.name,
      first: contact.first || firstNameOf(contact.name)
    });
    setRunStatus('Sending ' + (i + 1) + ' of ' + sendable.length + ' — ' + contact.name + '…');

    let res;
    try {
      // Open this person's conversation by URL, then send into it. No recipient
      // is ever typed, so there is no way to address the wrong person.
      await openThread(tabId, digits);
      await focusVoiceTab(tabId);
      res = await messageTab(tabId, {
        type: 'THC_SEND', viaThread: true, phone: contact.phone, digits, message
      });

      // Fall back to the compose flow when the conversation doesn't come up.
      // Both of these happen before anything is typed or sent, so retrying
      // cannot double-send:
      //   'thread'     — the address bar never picked up this number within
      //                  the wait (see sendToOpenThread in content.js)
      //   'messageBox' — the address bar DID confirm it, but no empty message
      //                  box rendered in time (see deliverMessage)
      // This has been seen to happen for a number with real prior history, so
      // it does NOT mean "no conversation exists" — exactly which of the two
      // above happened hasn't been pinned down yet, so the log below reports
      // the actual stage/error instead of guessing at a cause. The fallback
      // is the same either way: type the number and let Google Voice's own
      // autocomplete resolve it, which lands in the right thread regardless.
      if (res && !res.ok && (res.stage === 'thread' || res.stage === 'messageBox')) {
        logLine(contact.name + ' — direct-open (' + res.stage + ') didn\'t confirm: ' +
          (res.error || 'no detail') + ' — opening via search instead', 'skip');
        res = await composeWithRealInput(tabId, digits, contact.phone, message);

        // If Chrome wouldn't hand over input control, fall back to the scripted
        // path rather than skipping the person entirely.
        if (res && !res.ok && res.stage === 'attach') {
          logLine(contact.name + ' — ' + res.error + '; trying without it', 'skip');
          res = await messageTab(tabId, { type: 'THC_SEND', phone: digits, digits, message });
        }
      }
    } catch (err) {
      res = { ok: false, error: String(err && err.message ? err.message : err) };
    }

    done++;
    setProgress(done, sendable.length);

    if (res && res.ok) {
      sent++;
      logLine(contact.name + ' — sent', 'sent');
      await postLog(entryFor(batchId, contact, 'Sent', '', message));
    } else {
      failed++;
      const note = (res && res.error) || 'no response from the Google Voice tab';
      logLine(contact.name + ' — FAILED: ' + note, 'fail');
      await postLog(entryFor(batchId, contact, 'Failed', note, message));
      // Deliberate: a failure means the page is not where we think it is, so
      // stop rather than keep clicking. The rest is a human's call.
      logLine('Run stopped after a failure — ' + (sendable.length - i - 1) + ' not sent', 'fail');
      setRunStatus('Stopped on a failure. Check the Google Voice tab, then send the rest.');
      break;
    }

    if (i < sendable.length - 1 && !state.stopRequested) {
      await countdown(minDelay, maxDelay);
    }
  }

  if (!failed && !state.stopRequested) setRunStatus('Done — ' + sent + ' sent.');
  logLine('Batch ' + batchId + ' finished · ' + sent + ' sent, ' + failed + ' failed', failed ? 'fail' : 'sent');
  await flushPendingLogs();
  finishRun();
}

function finishRun() {
  state.running = false;
  el.reviewBtn.disabled = false;
  const actions = el.reviewPane.querySelector('.review-actions');
  if (actions) {
    actions.innerHTML = '<button class="btn-stop" id="closeRunBtn">Close</button>';
    const btn = $('closeRunBtn');
    if (btn) btn.addEventListener('click', () => { el.reviewPane.hidden = true; });
  }
}

/** Randomized pause between sends, counted down in the review pane. */
async function countdown(minDelay, maxDelay) {
  const total = minDelay + Math.random() * (maxDelay - minDelay);
  const until = Date.now() + total * 1000;
  while (Date.now() < until) {
    if (state.stopRequested) return;
    const left = Math.ceil((until - Date.now()) / 1000);
    setRunStatus('Waiting ' + left + 's…');
    await sleep(Math.min(250, Math.max(0, until - Date.now())));
  }
}

/* ---------- talking to the page ---------- */

async function findVoiceTab() {
  const tabs = await chrome.tabs.query({ url: 'https://voice.google.com/*' });
  if (!tabs.length) {
    throw new Error('No Google Voice tab open. Open https://voice.google.com and log in first.');
  }
  const onMessages = tabs.find((t) => /\/messages/.test(t.url || ''));
  if (!onMessages) {
    logLine('Heads up: the Google Voice tab is not on the Messages view — the "+" button may not be there.', 'skip');
  }
  return (onMessages || tabs[0]).id;
}

/* ---------- genuine browser-level input ---------- */

const DEBUGGER_PROTOCOL = '1.3';

/**
 * Types and clicks the way a person does — for real.
 *
 * Events made by a script carry a flag saying so, and Google Voice ignores them:
 * the number would land in the To box while the page never registered a
 * keystroke, so the recipient dropdown never opened. Chrome's debugging channel
 * injects input at the browser level instead, which the page cannot tell apart
 * from a human at the keyboard. It also doesn't need the page to hold keyboard
 * focus, which the panel was never able to give it.
 *
 * The cost is a "THC Text Blaster started debugging this browser" bar on the tab
 * while a blast runs. It disappears when the run ends.
 *
 * Only the compose flow needs this. Sending into a conversation opened by URL
 * works without it, so that route never attaches.
 */
async function withRealInput(tabId, run) {
  try {
    await chrome.debugger.attach({ tabId }, DEBUGGER_PROTOCOL);
  } catch (err) {
    // Already attached (DevTools open on that tab, usually) — carry on without.
    return { ok: false, stage: 'attach', error: 'Could not take input control of the tab: ' +
      (err && err.message ? err.message : err) };
  }
  try {
    return await run();
  } finally {
    try { await chrome.debugger.detach({ tabId }); } catch (_) { /* already gone */ }
  }
}

function cdp(tabId, method, params) {
  return chrome.debugger.sendCommand({ tabId }, method, params || {});
}

/** A real click at a point in the page. */
async function realClickAt(tabId, x, y) {
  const at = { x, y, button: 'left', clickCount: 1 };
  await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mouseMoved', x, y, button: 'none' });
  await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mousePressed', ...at });
  await cdp(tabId, 'Input.dispatchMouseEvent', { type: 'mouseReleased', ...at });
  await sleep(120);
}

/** Real keystrokes, one character at a time — what an autocomplete listens for. */
async function realType(tabId, text) {
  for (const ch of String(text)) {
    const code = ch.charCodeAt(0);
    const key = {
      key: ch,
      text: ch,
      unmodifiedText: ch,
      windowsVirtualKeyCode: code,
      nativeVirtualKeyCode: code
    };
    await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyDown', ...key });
    await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyUp', key: ch, windowsVirtualKeyCode: code });
    await sleep(55);
  }
}

/** A real named key — Enter, ArrowDown, Backspace. */
async function realKey(tabId, key, code, modifiers) {
  const base = { key, windowsVirtualKeyCode: code, nativeVirtualKeyCode: code, modifiers: modifiers || 0 };
  await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'rawKeyDown', ...base });
  await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyUp', ...base });
  await sleep(150);
}

/** Whole-text insertion, for the message body: no Enter, so nothing sends early. */
async function realInsert(tabId, text) {
  await cdp(tabId, 'Input.insertText', { text: String(text) });
  await sleep(200);
}

/** Ask the page where something is, waiting for it to appear. */
async function locate(tabId, what, number, timeout) {
  const res = await messageTab(tabId, { type: 'THC_LOCATE', what, number, timeout: timeout || 8000 });
  return res || { ok: false, what };
}

/**
 * The compose flow, driven with real input: click +, click the To box, type the
 * number, click the row that appears, click into the message area twice, type,
 * send. This is the path for someone with no conversation yet.
 *
 * === SAFETY: this must never place a phone call ===
 * A real run once did — Google Voice's calling panel sits right next to the
 * compose screen, and this flow presses Enter blind (see the ArrowDown+Enter
 * step below) because the recipient dropdown is invisible to this script. The
 * failure log showed the recipient had (apparently) been "accepted" and the
 * message typed, then nothing more — consistent with the run having actually
 * landed on an active call screen, where a compose flow's own elements
 * naturally can't be found. Root cause: the "did it work" check treated the To
 * field disappearing for ANY reason — including having navigated somewhere
 * completely different — as proof of success, because the placeholder string
 * used when no field is found ('(no To field)') contains no digits either, so
 * "digits are gone" read as true either way.
 *
 * Three layers now guard every step from here on:
 *   1. findToField() (content.js) hard-excludes anything sitting near the
 *      words "Call as" — structural, not a guess about placeholder text.
 *   2. looksLikeActiveCall() (content.js) is checked before ANY keypress that
 *      could commit to something, and again while waiting for confirmation —
 *      if the page ever looks like a call, the run stops immediately.
 *   3. "Accepted" now requires POSITIVE proof — a field that was actually
 *      found with the digits replaced by a chip, the address bar naming this
 *      number, OR the page having moved into the post-accept "chip + Add
 *      recipients" shape (see addRecipientsFieldPresent() in content.js) —
 *      never inferred from an ambiguous field disappearing.
 */
async function composeWithRealInput(tabId, digits, phone, message) {
  return withRealInput(tabId, async () => {
    const plus = await waitForComposeReady(tabId, digits);
    if (!plus.ok) return { ok: false, stage: 'newMessageBtn', error: 'Could not find the "+ Send new message" button, even after reloading the page' };
    await realClickAt(tabId, plus.x, plus.y);

    let row = { ok: false };
    for (let attempt = 1; attempt <= 2 && !row.ok; attempt++) {
      const to = await locate(tabId, 'toField', digits);
      if (!to.ok) return { ok: false, stage: 'toField', error: 'Could not find the "To" field' };

      await realClickAt(tabId, to.x, to.y);
      await realType(tabId, digits);
      await sleep(600);
      row = await locate(tabId, 'suggestion', digits, 9000);

      if (!row.ok && attempt === 1) {
        // Clear whatever is in there and try once more from a clean field.
        await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyDown', key: 'a', modifiers: 2,
          windowsVirtualKeyCode: 65 });
        await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyUp', key: 'a', modifiers: 2,
          windowsVirtualKeyCode: 65 });
        await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyDown', key: 'Backspace',
          windowsVirtualKeyCode: 8, nativeVirtualKeyCode: 8 });
        await cdp(tabId, 'Input.dispatchKeyEvent', { type: 'keyUp', key: 'Backspace',
          windowsVirtualKeyCode: 8, nativeVirtualKeyCode: 8 });
        await sleep(500);
      }
    }

    if (row.ok) {
      await realClickAt(tabId, row.x, row.y);
    } else {
      // No visible row to click — the fallback is a blind Enter, which is
      // exactly the step that needs the most scrutiny before it fires.
      const diag = await messageTab(tabId, { type: 'THC_DIAG', number: digits }) || {};
      if (diag.activeCall) {
        return {
          ok: false, stage: 'recipient',
          error: 'The page looks like an active call, not a text conversation. Stopped without pressing anything further.'
        };
      }
      if (!diag.toFound || !diag.toFocused) {
        return {
          ok: false, stage: 'recipient',
          error: 'Not confidently focused on the To field before committing the recipient — refusing to press Enter blind. ' +
            (diag.toFound ? 'To field reads "' + diag.toValue + '"' : 'No To field could be found at all') + '.'
        };
      }
      await realKey(tabId, 'ArrowDown', 40);
      await realKey(tabId, 'Enter', 13);
    }

    // Prove the recipient took before typing a word of the message. Two
    // independent, POSITIVE signals — a field that was actually found with the
    // digits replaced by a chip, or the address bar naming this number — never
    // an ambiguous "the field is gone" alone, which is also what a wrong page
    // (an active call, anywhere else) would look like.
    let accepted = false;
    for (let i = 0; i < 20 && !accepted; i++) {
      await sleep(300);
      const state = await messageTab(tabId, { type: 'THC_DIAG', number: digits }) || {};
      if (state.activeCall) {
        return {
          ok: false, stage: 'recipient',
          error: 'The page looks like an active call partway through committing the recipient. Stopped immediately.'
        };
      }
      const chipFormed = state.toFound && !String(state.toValue || '').replace(/\D/g, '').includes(digits);
      accepted = chipFormed || !!state.urlNamesNumber || !!state.addRecipientsFound;
    }
    if (!accepted) {
      const diag = await messageTab(tabId, { type: 'THC_DIAG', number: digits }) || {};
      const rows = (diag.rows || []).filter(Boolean);
      return {
        ok: false,
        stage: 'recipient',
        error: 'Could not confirm ' + phone + ' as the recipient. To field reads "' +
          (diag.toFound ? diag.toValue : '(no To field found)') + '"' +
          (diag.toFocused ? ' (focused)' : ' (NOT focused)') +
          ', under it: ' + (rows.length ? rows.map((t) => '"' + t + '"').join(', ') : 'nothing') +
          '. Nothing was typed.'
      };
    }

    // One more check right before typing anything real: confirmed-accepted a
    // moment ago is not the same as confirmed-safe right now.
    const preTypeCheck = await messageTab(tabId, { type: 'THC_DIAG', number: digits }) || {};
    if (preTypeCheck.activeCall) {
      return { ok: false, stage: 'messageBox', error: 'The page looks like an active call. Stopped before typing the message.' };
    }

    const box = await locate(tabId, 'emptyMessageBox', digits, 9000);
    if (!box.ok) return { ok: false, stage: 'messageBox', error: 'No empty message box appeared for this conversation' };
    await realClickAt(tabId, box.x, box.y);
    await realClickAt(tabId, box.x, box.y);
    await realInsert(tabId, message);

    const send = await locate(tabId, 'sendBtn', digits, 6000);
    if (!send.ok) return { ok: false, stage: 'send', error: 'The send button never became available' };
    await realClickAt(tabId, send.x, send.y);

    // Confirm it left: the box empties once Google Voice sends.
    for (let i = 0; i < 30; i++) {
      await sleep(300);
      const state = await messageTab(tabId, { type: 'THC_CLEARED' });
      if (state && state.ok) return { ok: true, how: 'compose · real input' };
    }
    return { ok: false, stage: 'confirm', error: 'The message box still has the text — it may not have sent' };
  });
}

/**
 * Waits for the "+ Send new message" button; if it never appears — most
 * likely a page that hasn't finished loading, e.g. after a network hiccup —
 * reloads the Google Voice tab once and tries again before giving up.
 *
 * Scoped to this one, earliest step on purpose: once real input has actually
 * begun (a click, a keystroke), reloading could interrupt something already
 * in-flight in a way that's harder to reason about than just failing cleanly
 * and letting the next recipient (or a human) start fresh.
 */
async function waitForComposeReady(tabId, digits) {
  const first = await locate(tabId, 'newMessageBtn', digits);
  if (first.ok) return first;

  try {
    await chrome.tabs.reload(tabId);
    await waitForTabComplete(tabId, 20000);
    await sleep(1500); // the page reporting "complete" and actually rendering aren't the same moment
  } catch (_) { /* if the reload itself fails, still try the fresh locate below */ }

  return locate(tabId, 'newMessageBtn', digits, 10000);
}

/**
 * Google Voice addresses every conversation by number:
 *   https://voice.google.com/u/0/messages?itemId=t.%2B15102143084
 * The account number (/u/0/, /u/1/, …) is taken from the tab's own URL rather
 * than assumed, since it differs per signed-in account.
 */
function threadUrl(tabUrl, digits) {
  const account = /voice\.google\.com\/(u\/\d+\/)/.exec(String(tabUrl || ''));
  const prefix = 'https://voice.google.com/' + (account ? account[1] : 'u/0/');
  return prefix + 'messages?itemId=t.%2B1' + digits;
}

/**
 * Opens a recipient's conversation by URL and waits for the page to settle.
 *
 * This replaces typing a recipient: no To field, no autocomplete to convince,
 * no dropdown row to click. Every failure up to now happened in those three
 * steps, and this route doesn't have them.
 */
/** Polls a tab until it reports status 'complete', or the timeout passes. */
async function waitForTabComplete(tabId, timeoutMs) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const t = await chrome.tabs.get(tabId);
    if (t.status === 'complete') return;
    await sleep(200);
  }
}

async function openThread(tabId, digits) {
  const tab = await chrome.tabs.get(tabId);
  const url = threadUrl(tab.url, digits);
  await chrome.tabs.update(tabId, { url, active: true });

  // Wait for the load, then a moment more for the conversation to render.
  await waitForTabComplete(tabId, 25000);
  await sleep(1200);
}

/**
 * Bring the Google Voice tab to the front before driving it.
 *
 * A page in a background tab can refuse a genuine text insertion, which drops
 * the typing to a scripted write that Angular ignores — the number lands in the
 * box, unformatted, and no recipient dropdown ever opens. Clicking "Start
 * sending" leaves focus in this panel, so the tab has to be raised deliberately.
 * The side panel stays open and keeps running the loop.
 */
async function focusVoiceTab(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (!tab.active) await chrome.tabs.update(tabId, { active: true });
    if (tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true });
  } catch (err) {
    console.warn('[THC] could not bring the Google Voice tab forward:', err);
  }
}

/**
 * sendMessage, with one re-injection retry: a Google Voice tab that was already
 * open when the extension was installed/reloaded has no content script in it.
 */
async function messageTab(tabId, payload) {
  try {
    const res = await chrome.tabs.sendMessage(tabId, payload);
    if (res) return res;
  } catch (_) { /* fall through to injection */ }

  await chrome.scripting.executeScript({ target: { tabId }, files: ['content.js'] });
  return chrome.tabs.sendMessage(tabId, payload);
}

/* ---------- logging ---------- */

function entryFor(batchId, contact, status, note, message) {
  return {
    batchId,
    name: contact.name,
    phone: contact.phone,
    group: contact.groupLabel || contact.group || '',
    personalized: state.mode === 'personalized',
    status,
    note,
    message,
    sender: state.senderName
  };
}

/** One row per send, appended in order. A logging failure is queued and retried
 *  at the end of the run — it must not abort a blast that is going fine. */
async function postLog(entry) {
  if (!state.webAppUrl) return;
  try {
    const res = await fetch(state.webAppUrl, {
      method: 'POST',
      // text/plain keeps this a "simple" request: Apps Script web apps don't
      // answer the CORS preflight that application/json would trigger.
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ action: 'log', entry }),
      redirect: 'follow'
    });
    const data = await res.json();
    if (!data || !data.ok) throw new Error((data && data.error) || 'the script rejected the row');
  } catch (err) {
    state.pendingLogs.push(entry);
    logLine('Sheet log failed for ' + entry.name + ' (will retry at the end)', 'skip');
  }
}

async function flushPendingLogs() {
  if (!state.pendingLogs.length) return;
  const queue = state.pendingLogs.slice();
  state.pendingLogs = [];
  let stillFailing = 0;
  for (const entry of queue) {
    const before = state.pendingLogs.length;
    await postLog(entry);
    if (state.pendingLogs.length > before) stillFailing++;
  }
  logLine(
    stillFailing
      ? stillFailing + ' log row(s) still not written to the sheet — the texts went out regardless'
      : 'Queued log rows written to the sheet',
    stillFailing ? 'fail' : 'sent'
  );
}

/* ---------- session log ---------- */

function logLine(text, kind) {
  if (!state.logRows) el.log.textContent = '';
  state.logRows++;

  const row = document.createElement('div');
  row.className = 'log-row';
  const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  row.innerHTML =
    '<span class="who">' + escapeHtml(text) + '</span>' +
    '<span class="st-' + (kind || 'skip') + '">' + escapeHtml(time) + '</span>';
  el.log.appendChild(row);
  el.log.scrollTop = el.log.scrollHeight;
}

/* ---------- misc ---------- */

function escapeHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

/* ---------- entry points ---------- */

if (typeof document !== 'undefined') {
  document.addEventListener('DOMContentLoaded', boot);
}

if (typeof module !== 'undefined' && module.exports) {
  module.exports = {
    CANONICAL_GROUPS,
    normalizePhone,
    formatPhone,
    firstNameOf,
    renderMessageForFactory,
    hasPlaceholder,
    deriveGroups,
    contactKey,
    estimateRunSeconds,
    formatDuration,
    matchesQuery,
    planRun,
    validateNewContact,
    ADD_GROUP_OPTIONS,
    threadUrl,
    nameFromEmail,
    insertAtCursor,
    makeBatchId
  };
}
