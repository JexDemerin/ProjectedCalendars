// Opens the side panel when the toolbar icon is clicked.
// The side panel (not a popup) is used deliberately: Chrome closes an action
// popup the instant it loses focus, which would kill a blast mid-run. The side
// panel stays open while you click around Google Voice.

chrome.runtime.onInstalled.addListener(() => {
  if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
    chrome.sidePanel
      .setPanelBehavior({ openPanelOnActionClick: true })
      .catch(() => {});
  }
});

// Fallback for Chrome builds where setPanelBehavior isn't honored.
chrome.action.onClicked.addListener((tab) => {
  if (chrome.sidePanel && chrome.sidePanel.open) {
    chrome.sidePanel.open({ windowId: tab.windowId }).catch(() => {});
  }
});
