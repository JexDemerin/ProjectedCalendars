# Icons

`logo-mark.png` and the four `icon-*.png` files are generated from the SVG sources
in `src/` by `../../tools/build-icons.sh`.

## Using the real artwork instead

The SVGs are a **hand trace** of the Together Homecare logo, drawn by eye from a
screenshot. They are close, not exact — the heart in particular.

To use the real logo, no code change is needed:

1. Save the agency logo as **`logo-mark.png`** in this folder, replacing the traced
   one. The side-panel header scales whatever it finds (24px tall, up to 104px wide,
   aspect preserved), so the full lockup with the words or just the mark both work.
2. For the toolbar, replace `icon-16.png`, `icon-32.png`, `icon-48.png` and
   `icon-128.png` with square crops at those exact pixel sizes. Chrome requires the
   sizes to match the names. Crop to the mark alone — the words turn to mush below
   about 40px.

Don't re-run `build-icons.sh` after that; it would overwrite the real files with the
traced ones. Delete `src/` if you want to remove that possibility.
