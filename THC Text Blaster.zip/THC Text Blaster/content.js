/* THC Text Blaster — Google Voice content script.
 *
 * Runs inside https://voice.google.com. Receives one send request at a time from
 * the side panel and performs the real UI steps: open a new message, type the
 * number, put the body in the message box, and click send.
 *
 * === HOW ELEMENTS ARE FOUND ===
 * Confirmed against a real page on 2026-08-12. The first version of this file
 * matched only on internal attributes (aria-label, data-*) and fell over on the
 * very first step: the "+ Send new message" button carries no aria-label, so
 * nothing matched and no message ever got sent.
 *
 * So each entry in GV below can be found three ways, tried in order:
 *   1. css         — exact selectors, fastest and most precise when they hold
 *   2. placeholder — for the two text fields, whose placeholder text is visible
 *   3. text        — the words a human reads on screen
 * The words on screen are the most durable of the three: Google restructures
 * markup far more often than it renames a button. Attributes stay first because
 * when they do match they're unambiguous.
 *
 * What the live page showed:
 *   newMessageBtn — no aria-label; visible text "Send new message"   (text match)
 *   toField       — placeholder "Type a name or phone number"        (matched)
 *   toSuggestion  — for a new number, a row reading "Send to (415) 294-1081";
 *                   for a number texted before, its existing conversation with no
 *                   "Send to" wording at all — so rows are matched on the NUMBER
 *   messageBox    — placeholder "Type a message"                     (matched)
 *   sendBtn       — the paper-plane icon, has a "Send"-ish label      (matched)
 *
 * Re-check any time sends start failing: press Ctrl+Shift+G on the Google Voice
 * tab, or use "Capture Google Voice selectors" in the side panel's settings. The
 * report names how each element was found, or that it wasn't.
 *
 * Notes carried over from the WellSky scanner that apply here too:
 *   - Don't use element.click() blindly — dispatch a real pointer/click sequence,
 *     because some Google apps read the click position, and a bare .click()
 *     dispatches at 0,0.
 *   - Never use fixed waits for async UI. Poll for the element to appear/enable.
 *   - React/Angular-controlled inputs ignore `input.value = x`. Set the value via
 *     the native setter and dispatch input+change so the framework notices.
 */

const GV = {
  // Button that opens a brand-new conversation (the "+" / "Send new message").
  newMessageBtn: {
    what: 'the "+ Send new message" button',
    css: [
      'a[aria-label="Send new message"]',
      'button[aria-label="Send new message"]',
      'a[gv-test-id="send-new-message"]',
      '[data-e2e-send-new-message]'
    ],
    text: ['send new message']
  },
  // The "To" field where the recipient number is typed.
  toField: {
    what: 'the "To" field',
    css: [
      'input[aria-label="Type a name or phone number"]',
      'input[placeholder*="name or phone" i]',
      'input[type="text"][aria-label*="phone" i]'
    ],
    placeholder: ['type a name or phone number', 'name or phone']
  },
  // Appears once a first recipient is accepted: the single "To" field is
  // replaced by a chip plus this second field, for adding more people to the
  // conversation. Never present on a fresh compose screen, and never part of
  // the calling panel — so finding it is itself proof a recipient was set.
  addRecipientsField: {
    what: 'the "Add recipients" field',
    css: [
      'input[aria-label*="add recipients" i]',
      'input[placeholder*="add recipients" i]'
    ],
    placeholder: ['add recipients']
  },
  // The suggestion row after typing a raw number: "Send to (415) 294-1081".
  toSuggestion: {
    what: 'the "Send to <number>" row',
    css: [
      'div[aria-label^="Send to" i]',
      '[role="option"]',
      '.recipient-suggestion'
    ],
    text: ['send to']
  },
  // The message body box.
  messageBox: {
    what: 'the message box',
    css: [
      'textarea[aria-label="Type a message"]',
      'div[aria-label="Type a message"][contenteditable="true"]',
      'textarea[placeholder*="message" i]',
      'div[contenteditable="true"][aria-label*="message" i]'
    ],
    placeholder: ['type a message']
  },
  // The send button — a paper-plane icon with no text of its own.
  sendBtn: {
    what: 'the send button',
    css: [
      'button[aria-label="Send message"]',
      'button[aria-label="Send"]',
      'div[role="button"][aria-label*="Send" i]',
      'button[aria-label*="Send" i]'
    ]
  }
};

/* Re-injection guard. The side panel re-injects this file when a send gets no
 * answer, because a Google Voice tab that was already open when the extension
 * was loaded has no content script in it. If that injection lands in a tab that
 * DOES already have the script, a second onMessage listener would run sendOne a
 * second time for every request — i.e. text everyone twice. Register once. */
if (window.__thcTextBlasterReady) {
  console.log('[THC] content script already active in this tab; skipping re-registration');
} else {
  window.__thcTextBlasterReady = true;

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'THC_SEND') {
      const run = msg.viaThread ? sendToOpenThread(msg) : sendOne(msg);
      run.then(sendResponse).catch(err => sendResponse({ ok: false, error: String(err && err.message || err) }));
      return true; // async
    }
    if (msg.type === 'THC_CAPTURE') {
      sendResponse({ ok: true, capture: captureInterface() });
      return true;
    }
    if (msg.type === 'THC_DIAG') {
      sendResponse(diagnoseRecipient(String(msg.number || '').replace(/\D/g, '')));
      return true;
    }
    if (msg.type === 'THC_CLEARED') {
      sendResponse(messageBoxCleared());
      return true;
    }
    if (msg.type === 'THC_ACCOUNT_NUMBER') {
      sendResponse({ ok: true, digits: readAccountNumber() });
      return true;
    }
    if (msg.type === 'THC_LOCATE') {
      locateWait(msg).then(sendResponse)
        .catch(err => sendResponse({ ok: false, error: String(err && err.message || err) }));
      return true; // async
    }
    if (msg.type === 'THC_PROBE') {
      probeRecipient(msg).then(sendResponse)
        .catch(err => sendResponse({ ok: false, error: String(err && err.message || err) }));
      return true; // async
    }
  });

  // Keyboard capture on the GV page itself (mouse can't hover + trigger at once).
  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.shiftKey && (e.key === 'G' || e.key === 'g')) {
      const cap = captureInterface();
      console.log('=== THC Text Blaster — Google Voice interface capture ===');
      console.log(cap);
      console.log('Copy the above and compare to the GV object in content.js.');
    }
  });
}

/* ---------- the send sequence ---------- */

/**
 * Sends into the conversation the tab is already showing.
 *
 * The side panel navigates to voice.google.com/u/N/messages?itemId=t.%2B1<number>
 * first, which is how Google Voice addresses a conversation. That skips the To
 * field entirely — no typing a recipient, no autocomplete to convince, no
 * dropdown row to find. Those three steps caused every failure so far; this path
 * doesn't have them.
 */
async function sendToOpenThread({ phone, digits, message }) {
  const number = String(digits || phone || '').replace(/\D/g, '');

  // The address bar is the proof of who we're talking to. Confirm it names this
  // number before typing anything, so a conversation that didn't load can never
  // become a message sent to whoever was on screen instead.
  const addressed = await poll(() => (urlNames(number) ? true : null), 10000);
  if (!addressed) {
    return {
      ok: false,
      stage: 'thread',
      error: 'The open conversation is not ' + phone + ' (address bar reads "' +
             location.search + '"). Nothing was typed.'
    };
  }

  return deliverMessage(message, 'thread');
}

/** Does the current URL address this number? */
function urlNames(number) {
  if (!number) return false;
  let search = location.search || '';
  try { search = decodeURIComponent(search); } catch (_) { /* keep raw */ }
  return digitsIn(search).includes(number);
}

async function sendOne({ phone, digits, message }) {
  const number = String(digits || phone || '').replace(/\D/g, '');

  // 1) Open a new conversation.
  const plus = await waitFor(GV.newMessageBtn, 8000);
  if (!plus) return fail('newMessageBtn');
  realClick(plus.el);

  // 2) Wait for a FRESH compose screen, then type the number.
  //    "Fresh" means the To field is empty. After a send we're sitting inside the
  //    conversation just sent to, and the compose screen takes a moment to swap
  //    in — grabbing the outgoing one and typing into it goes nowhere, which is
  //    what made the second recipient in a run fail while the first succeeded.
  const to = await poll(() => findToField(), 8000);
  if (!to) return fail('toField');

  // Clear anything left in it first. A previous failed attempt can leave the
  // number sitting there, and clicking "+" does NOT wipe it: text put in by a
  // scripted write is invisible to Google Voice, so as far as the page is
  // concerned the box is already empty and there is nothing to reset. Waiting
  // for it to clear on its own blocks every later run.
  if (fieldValue(to.el).trim()) {
    focusField(to.el);
    selectAllIn(to.el);
    if (!insertText(to.el, '')) writeValue(to.el, '');
    await sleep(250);
  }

  // 3) Commit the recipient. Google Voice offers "Send to <number>" for a number
  //    that isn't a saved contact; a number you've texted before opens that
  //    conversation instead. Either is fine — we just need it accepted, so fall
  //    back to Enter when no row appears rather than treating it as a failure.
  const urlBefore = location.href;
  let suggestion = null;
  let typed = { ok: false, method: 'none' };

  // Two attempts: the dropdown sometimes doesn't open on the first edit straight
  // after a send. Retyping is harmless — nothing has been committed yet.
  const liveToField = () => {
    const found = findToField();
    return found ? found.el : null;
  };

  for (let attempt = 1; attempt <= 2 && !suggestion; attempt++) {
    // Click into the box before typing, the way a person does. An Angular field
    // that has never been clicked may not have woken its autocomplete up.
    await clickField(liveToField(), 1);
    typed = await typeInto(liveToField, phone, { keys: attempt === 2 });
    if (!typed.ok) {
      const live = liveToField();
      return {
        ok: false,
        stage: 'toField',
        error: 'The number would not stay in the To field' +
          (live ? ' — it reads "' + fieldValue(live) + '"' : ' — the field went away as we typed') +
          ' (' + typed.method + ', page focused: ' + (document.hasFocus() ? 'yes' : 'no') + ')'
      };
    }
    // A second click after typing, again mirroring the human sequence: click,
    // type, click, and the row appears.
    await clickField(liveToField(), 1);
    suggestion = await poll(() => suggestionFor(number, liveToField()), 5000);
    if (!suggestion && attempt === 1) {
      const live = liveToField();
      if (live) {
        focusField(live);
        selectAllIn(live);
        if (!insertText(live, '')) writeValue(live, '');
      }
      await sleep(700);
    }
  }

  if (suggestion) {
    realClick(suggestion.el);
  } else {
    // Same class of risk as the real-input path (see composeWithRealInput in
    // sidepanel.js): pressing Enter with no visible row to click is a guess
    // about what currently has focus. Refuse rather than guess blind.
    if (!isFocused(to.el)) {
      return {
        ok: false,
        stage: 'recipient',
        error: 'Not confidently focused on the To field before committing the recipient — refusing to press Enter blind.'
      };
    }
    pressEnter(to.el);
  }

  // 3b) PROVE the recipient took before typing anything. This is a safety step,
  //     not a nicety: with no recipient set, the message box found below can be
  //     the one from the PREVIOUS conversation still open behind the compose
  //     screen — which is how a message meant for one person gets typed into
  //     someone else's thread. Bail out here instead.
  //
  //     Checked on every poll tick, not just once: if the page ends up looking
  //     like an active call at any point in here, stop immediately rather than
  //     waiting out the rest of the timeout.
  const accepted = suggestion
    // The row disappears once Google Voice accepts it. If it's still sitting
    // there, the click didn't take.
    ? await poll(() => {
        if (looksLikeActiveCall()) return 'call';
        return suggestionFor(number, liveToField()) ? null : true;
      }, 6000)
    // No row: Enter drops you into the conversation, which shows up as the
    // compose screen going away, the number being replaced by a chip, or the
    // page navigating. Any one of those means it took.
    : await poll(() => {
        if (looksLikeActiveCall()) return 'call';
        return recipientCommitted(liveToField() || to.el, number, urlBefore) ? true : null;
      }, 6000);

  if (accepted === 'call') {
    return {
      ok: false,
      stage: 'recipient',
      error: 'The page looks like an active call, not a text conversation. Stopped without typing anything further.'
    };
  }

  if (!accepted) {
    return {
      ok: false,
      stage: 'recipient',
      error: suggestion
        ? 'Google Voice did not accept ' + phone + ' — the suggestion row stayed on screen after clicking it. Nothing was typed.'
        : 'No dropdown row naming ' + phone + ' appeared after two tries, and Enter did not set the ' +
          'recipient. The live To field reads "' + (liveToField() ? fieldValue(liveToField()) : '(gone)') +
          '" (entered by ' + typed.method + ', page focused: ' + (document.hasFocus() ? 'yes' : 'no') +
          '). Nothing was typed.'
    };
  }

  if (looksLikeActiveCall()) {
    return { ok: false, stage: 'recipient', error: 'The page looks like an active call. Stopped before typing the message.' };
  }

  return deliverMessage(message, 'compose');
}

/**
 * The half both routes share: put the body in the message box and send it.
 * The box must be EMPTY — text already in it belongs to another conversation.
 */
async function deliverMessage(message, via) {
  const box = await poll(() => {
    const found = findElement(GV.messageBox);
    if (!found || isDisabled(found.el)) return null;
    return fieldValue(found.el).trim() ? null : found;
  }, 8000);
  if (!box) {
    return { ok: false, stage: 'messageBox', error: 'No empty message box appeared for this conversation' };
  }

  const liveMessageBox = () => {
    if (box.el && box.el.isConnected) return box.el;
    const found = findElement(GV.messageBox);
    return found ? found.el : null;
  };

  // Two clicks into the message area before typing — the sequence that works by
  // hand. The first click moves into the conversation, the second lands in the
  // box itself.
  await clickField(liveMessageBox(), 2);

  const typedBody = await typeInto(liveMessageBox, message);
  if (!typedBody.ok) {
    return {
      ok: false,
      stage: 'messageBox',
      error: 'The message would not stay in the message box (' + typedBody.method + ')'
    };
  }

  // Send. If the button can't be found or stays disabled, Enter in the message
  // box is how Google Voice sends anyway — so try that before giving up.
  const send = await waitForEnabled(GV.sendBtn, 4000) || nearbySendButton(liveMessageBox());
  if (send) realClick(send.el);
  else pressEnter(liveMessageBox());

  // Confirm it actually went: the message box empties once sent. Better than
  // sleeping and assuming — a silent non-send would otherwise be logged as
  // "Sent" and nobody would know the message never arrived.
  const cleared = await poll(() => {
    const live = liveMessageBox();
    return live && fieldValue(live).trim() === '' ? true : null;
  }, 8000);
  if (!cleared) {
    return {
      ok: false,
      stage: 'confirm',
      error: 'The message box still has the text' + (send ? '' : ' (no send button found; pressed Enter)') +
             ' — it may not have sent'
    };
  }

  return { ok: true, how: (via || 'compose') + ' · ' + (send ? send.how : 'Enter key') };
}

function fail(name) {
  const spec = GV[name] || { what: name };
  return { ok: false, stage: name, error: 'Could not find ' + spec.what + ' on the page' };
}

/**
 * The "Send to <number>" row for the number we just typed.
 *
 * Checks every candidate rather than the first, because [role="option"] also
 * matches the calling panel's contact suggestions (Liz Toki, Renessa White, …).
 * Only a row naming our number is our recipient — clicking any other row would
 * address the message to the wrong person.
 */
function suggestionFor(number, toEl) {
  const rows = [];
  const seen = new Set();
  const add = (el, how) => {
    if (!el || seen.has(el) || !isVisible(el)) return;
    seen.add(el);
    rows.push({ el, how });
  };

  // The shapes we know: a "Send to <number>" row, or a listbox option.
  findAll(GV.toSuggestion).forEach((r) => {
    if (!number || digitsIn(renderedText(r.el)).includes(number)) add(r.el, r.how);
  });

  // Anything else in the dropdown that names the number. A number texted before
  // is offered as its existing conversation — no "Send to" wording at all — so
  // matching only that phrase misses every repeat recipient.
  rowsNamingNumber(number, toEl).forEach((el) => add(el, 'row naming ' + number));

  if (!rows.length) return null;

  // "Send to" is the unambiguous one when it's there.
  const sendTo = rows.find((r) => renderedText(r.el).startsWith('send to'));
  return sendTo || rows[0];
}

/**
 * Rows in the dropdown under the To field whose text contains the number typed.
 *
 * Anchored to the To field on purpose. The conversation list on the left also
 * shows numbers, and some of those threads have two people in them — clicking
 * one would send to the wrong conversation entirely. Requiring the row to sit
 * just below the To field keeps this to the dropdown. Once the To field is gone
 * (we're in the conversation), there is nothing to pick and this returns none.
 */
function rowsNamingNumber(number, toEl) {
  if (!number || !toEl || !isVisible(toEl)) return [];
  const anchor = toEl.getBoundingClientRect();

  return queryDeep('button,[role="button"],[role="option"],a,li,div,span')
    .filter((e) => {
      if (e === toEl || e.contains(toEl)) return false;
      const raw = norm(e.textContent);
      if (raw.length > 60 || !digitsIn(raw).includes(number)) return false;
      if (!isVisible(e)) return false;
      const r = e.getBoundingClientRect();
      // Below the To field, close to it, and overlapping its column.
      if (r.top < anchor.top || r.top - anchor.bottom > 400) return false;
      if (r.right < anchor.left || r.left > anchor.right) return false;
      return digitsIn(renderedText(e)).includes(number);
    })
    .sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length)
    .map(clickableAncestor);
}

/** Just the digits of whatever text is passed in. */
function digitsIn(s) {
  return String(s == null ? '' : s).replace(/\D/g, '');
}

/**
 * Did pressing Enter actually set the recipient? Any of three signs will do,
 * because Google Voice behaves differently for a new number than for one you've
 * texted before. Deliberately conservative: if none of them hold, the caller
 * stops without typing, rather than risk typing into someone else's thread.
 */
function recipientCommitted(toEl, number, urlBefore) {
  if (location.href !== urlBefore) return true;   // navigated into the conversation
  if (!isVisible(toEl)) return true;              // the compose screen is gone
  return digitsIn(fieldValue(toEl)) !== number;   // the number became a chip
}

/* ---------- finding things ---------- */

/**
 * EVERY element matching a GV entry, from all three strategies, in order of
 * confidence. Collecting all of them matters: a generic selector like
 * [role="option"] also matches the contact list in the calling panel, and an
 * earlier version stopped at that first wrong hit and never tried the words —
 * so the "Send to <number>" row went unclicked and a message was composed with
 * no recipient. Callers pick the right one; nothing assumes the first is it.
 */
function findAll(spec) {
  const out = [];
  const seen = new Set();
  const add = (el, how) => {
    if (!el || seen.has(el) || !isVisible(el)) return;
    seen.add(el);
    out.push({ el, how });
  };

  for (const sel of (spec.css || [])) {
    queryDeep(sel).forEach((e) => add(e, 'selector ' + sel));
  }
  for (const want of (spec.placeholder || [])) {
    fields().forEach((e) => { if (fieldLabel(e).includes(want)) add(e, 'placeholder "' + want + '"'); });
  }
  for (const want of (spec.text || [])) {
    byTextAll(want).forEach((e) => add(e, 'visible text "' + want + '"'));
  }
  return out;
}

/** The best single match, for the elements where there's only ever one. */
function findElement(spec) {
  return findAll(spec)[0] || null;
}

/**
 * The compose screen's "To" field specifically.
 *
 * The calling panel on the right has a lookalike ("Enter a name or number") that
 * can match the same selectors. Typing a recipient into THAT field puts the
 * number somewhere that will never open a message dropdown — and, worse, is the
 * field for placing a call. The compose row is the one with "To" beside it.
 */
function findToField() {
  // Hard exclusion, checked first and unconditionally: nothing sitting inside
  // the calling panel is ever a candidate, regardless of what else matches
  // about it. This is deliberately not the only defense — see
  // isNearCallingPanel()'s own comment — but every other check here is a
  // judgment call (a label, a placeholder string) that could be wrong about a
  // page this script has never fully confirmed. This one isn't a judgment
  // call: text OR field, if "Call as" is nearby, it is never touched.
  const cands = findAll(GV.toField).filter((c) => !isNearCallingPanel(c.el));
  if (!cands.length) return null;

  // The compose row reads "To" next to the field.
  const labelled = cands.find((c) => {
    const p = c.el.parentElement;
    return p && /^to\b/.test(renderedText(p));
  });
  if (labelled) return labelled;

  // Otherwise go by the compose field's own placeholder ("Type a name or phone
  // number"); the calling panel's says "Enter a name or number".
  const byPlaceholder = cands.find((c) =>
    norm(c.el.getAttribute('placeholder')).includes('name or phone'));
  if (byPlaceholder) return byPlaceholder;

  // Nothing identifiable as the compose field — return nothing rather than the
  // calling panel's lookalike. Waiting costs a retry; typing a number into the
  // call box and pressing Enter could place a call to the person instead.
  return null;
}

/**
 * The smallest visible element containing the words "Call as" — the calling
 * panel's own container — or null if that text isn't on the page at all.
 * Smallest wins for the same reason byTextAll() picks the smallest match
 * elsewhere in this file: the phrase also "appears" in every ancestor up to
 * <body>, and treating <body> itself as "the calling panel" would flag every
 * field on the page as unsafe, drowning out the real signal.
 */
function callingPanelContainer() {
  const textMatches = pageElements().filter((e) => {
    if (!isVisible(e)) return false;
    const t = renderedText(e);
    return t && t.length < 400 && t.toLowerCase().includes('call as');
  });
  if (!textMatches.length) return null;
  textMatches.sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length);

  // The smallest match is usually just the label itself ("Call as"), a
  // sibling of the field it labels rather than its ancestor — containment
  // against the bare label would miss the field entirely. Walk up from it to
  // the nearest ancestor that also holds a field or button, so the container
  // used for containment checks actually wraps the panel's controls.
  let n = textMatches[0];
  for (let i = 0; n && n.nodeType === 1 && i < 5; i++) {
    if (n.querySelector('input,textarea,[contenteditable="true"],button')) return n;
    n = n.parentElement;
  }
  return textMatches[0];
}

/**
 * True once Google Voice has swapped the single "To" field for a chip plus
 * the "Add recipients" field — the shape it switches to the moment a
 * recipient is accepted. That's exactly the moment the classic To field
 * (what findToField() looks for) disappears, which is why "the field is
 * gone" was never allowed to mean success on its own (see composeWithRealInput
 * in sidepanel.js). "Add recipients" wording only exists once a first
 * recipient is already set — not on a fresh compose screen, not in the
 * calling panel — so finding it is itself positive proof, the same category
 * of evidence as a formed chip or the address bar naming the number.
 */
function addRecipientsFieldPresent() {
  return findAll(GV.addRecipientsField).some((c) => !isNearCallingPanel(c.el));
}

/**
 * True if this element sits inside (or wraps) the "Call as" calling panel —
 * the one part of Google Voice this extension must never type into or click.
 * A number typed there and committed with Enter places a real call.
 *
 * Structural, not a guess: finds the calling panel's own container and checks
 * containment, rather than trusting a placeholder string this script has
 * never fully confirmed against the live page. If the compose screen's own To
 * field hasn't rendered yet — a slow-loading page, say — this can only ever
 * say "not safe to use," never mistake the calling panel for it.
 */
function isNearCallingPanel(el) {
  const panel = callingPanelContainer();
  if (!panel) return false;
  return panel === el || panel.contains(el) || el.contains(panel);
}

/**
 * True if the page looks like it's showing an active phone call rather than a
 * text conversation. Checked at every safety point in a real-input send: if
 * this is ever true, the run stops immediately, no matter what else looks
 * fine. A heuristic — this script has never captured the live markup of an
 * actual in-progress GV call — so it's written to over-trigger rather than
 * under-trigger; a text blast that stops on a false alarm costs a retry, a
 * blast that doesn't stop on a real call does not get a second chance.
 */
function looksLikeActiveCall() {
  const text = norm(document.body.innerText || '');
  if (!text) return false;
  if (/\bend call\b/.test(text)) return true;
  if (/\bcalling(\.\.\.|…)/.test(text)) return true;
  if (/\bhang up\b/.test(text)) return true;
  if (/\bmute\b/.test(text) && /\bspeaker\b/.test(text)) return true;
  return false;
}

/**
 * Every element on the page, INCLUDING inside shadow roots.
 *
 * document.querySelectorAll does not look inside a shadow root, so any part of
 * the page built as a web component is invisible to it. Google Voice's recipient
 * dropdown is a candidate for exactly that: the row is plainly on screen, yet
 * ordinary searches found nothing. Walking the shadow roots costs a few
 * milliseconds and removes the whole class of blind spot.
 *
 * Memoised briefly so one poll tick doesn't walk the tree four times.
 */
let elementCache = { at: 0, list: [] };
function pageElements() {
  const now = Date.now();
  if (now - elementCache.at < 100 && elementCache.list.length) return elementCache.list;

  const out = [];
  const walk = (root) => {
    let els;
    try { els = root.querySelectorAll('*'); } catch (_) { return; }
    for (const el of els) {
      out.push(el);
      if (el.shadowRoot) walk(el.shadowRoot);
    }
  };
  walk(document);

  elementCache = { at: now, list: out };
  return out;
}

/** querySelectorAll that reaches into shadow roots. */
function queryDeep(selector) {
  return pageElements().filter((el) => {
    try { return el.matches(selector); } catch (_) { return false; }
  });
}

/** Every text-entry element, including contenteditable divs. */
function fields() {
  return queryDeep('input,textarea,[contenteditable="true"]');
}

/** Placeholder + aria-label of a field, lowercased, for loose matching. */
function fieldLabel(e) {
  return norm([e.getAttribute('placeholder'), e.getAttribute('aria-label'), e.getAttribute('data-placeholder')]
    .filter(Boolean).join(' '));
}

/**
 * Visible elements whose text contains `want`, smallest first, each resolved up
 * to whatever is actually clickable. Smallest first because the phrase also
 * appears in every ancestor up to <body>, and clicking <body> does nothing.
 */
function byTextAll(want) {
  const matches = queryDeep('button,[role="button"],[role="option"],a,li,div,span')
    .filter((e) => {
      const raw = norm(e.textContent);
      // Cheap checks first. The length guard keeps a whole panel that happens to
      // contain the phrase from being treated as the button.
      if (!raw.includes(want) || raw.length > want.length + 40) return false;
      if (!isVisible(e)) return false;
      // Then the real test. textContent counts words inside hidden children too,
      // so a panel whose dropdown just closed still "contains" the row's text —
      // which made "has the suggestion gone?" impossible to answer. renderedText
      // is what a person can actually see. It forces layout, so it only runs on
      // the handful of candidates that already passed the cheap checks.
      return renderedText(e).includes(want);
    });

  matches.sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length);
  return matches.map(clickableAncestor);
}

/** The words actually on screen for this element — hidden children excluded. */
function renderedText(el) {
  if (!el) return '';
  return norm(el.innerText != null ? el.innerText : el.textContent);
}

/** The nearest ancestor that behaves like a control, else the element itself. */
function clickableAncestor(el) {
  let n = el;
  for (let i = 0; n && n.nodeType === 1 && i < 5; i++) {
    if (n.matches && n.matches('button,[role="button"],[role="option"],[role="menuitem"],a,[tabindex]')) return n;
    n = n.parentElement;
  }
  return el;
}

/**
 * Last resort for the send button: the right-most control sitting next to the
 * message box. The send arrow is always at the end of the compose row, so this
 * holds even if its label changes.
 */
function nearbySendButton(box) {
  let scope = box;
  const boxRect = box.getBoundingClientRect();
  for (let i = 0; scope && i < 4; i++) {
    scope = scope.parentElement;
    if (!scope) break;
    const buttons = Array.from(scope.querySelectorAll('button,[role="button"]'))
      .filter((b) => isVisible(b) && !b.contains(box) && !isDisabled(b))
      .filter((b) => b.getBoundingClientRect().left >= boxRect.left);
    if (buttons.length) {
      buttons.sort((a, b) => b.getBoundingClientRect().left - a.getBoundingClientRect().left);
      return { el: buttons[0], how: 'the control at the end of the message row' };
    }
  }
  return null;
}

/* ---------- DOM helpers ---------- */
function waitFor(spec, timeout) {
  return poll(() => findElement(spec), timeout);
}
function waitForEnabled(spec, timeout) {
  return poll(() => {
    const found = findElement(spec);
    if (!found) return null;
    return isDisabled(found.el) ? null : found;
  }, timeout);
}
function isDisabled(e) {
  return !!(e.disabled || e.getAttribute('aria-disabled') === 'true');
}
function poll(fn, timeout) {
  return new Promise(resolve => {
    const start = Date.now();
    (function tick() {
      let v = null;
      try { v = fn(); } catch (_) { v = null; }
      if (v) return resolve(v);
      if (Date.now() - start > timeout) return resolve(null);
      setTimeout(tick, 120);
    })();
  });
}
function isVisible(e) {
  if (!e || e.nodeType !== 1) return false;
  // A zero-size box is on the page but not on screen — e.g. a collapsed panel.
  const r = e.getBoundingClientRect();
  if (!r.width && !r.height) return false;
  let n = e;
  while (n && n.nodeType === 1) {
    const cs = getComputedStyle(n);
    if (cs.display === 'none' || cs.visibility === 'hidden') return false;
    n = n.parentElement;
  }
  return true;
}
function norm(s) {
  return String(s == null ? '' : s).replace(/\s+/g, ' ').trim().toLowerCase();
}
function realClick(e) {
  const r = e.getBoundingClientRect();
  const x = r.left + r.width / 2, y = r.top + r.height / 2;
  for (const type of ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click']) {
    e.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, clientX: x, clientY: y }));
  }
}
/**
 * Puts text in a field and makes Google Voice believe it was typed.
 *
 * Assigning .value and firing an input event is not enough here: the To field
 * accepted the value long enough for a check to pass, then Angular reset it to
 * empty, so the page never saw a recipient and no dropdown ever opened.
 *
 * execCommand('insertText') is tried first because the browser performs a real
 * edit and fires a trusted beforeinput/input pair, which frameworks honour. If
 * the value still doesn't stick, it falls back to typing character by character
 * with key events, which is as close to a human as script can get.
 */
async function typeInto(target, text, opts) {
  const value = String(text == null ? '' : text);
  // keys:true skips straight to per-character typing. The whole-value insert can
  // land the text while an autocomplete that listens for keystrokes stays shut,
  // so the retry escalates rather than repeating what already didn't work.
  const forceKeys = !!(opts && opts.keys);
  // Angular replaces the field element as it re-renders. Holding a reference
  // across steps means writing into a node that has already left the page — the
  // value looks set from script and the screen stays empty. Re-resolve instead.
  const get = typeof target === 'function' ? target : () => target;

  let method = 'none';
  let el = get();
  if (!el || !el.isConnected) return { ok: false, method: method };

  if (!forceKeys) {
    focusField(el);
    selectAllIn(el);
    if (insertText(el, value)) method = 'real edit';
    else { writeValue(el, value); method = 'scripted write'; }

    // Give the framework a change-detection cycle to reject it.
    await sleep(250);
    el = get();
    if (el && el.isConnected && matchesTyped(el, value) && method === 'real edit') {
      return { ok: true, method: method };
    }
  }

  // Second attempt: one character at a time, with keystrokes around each, and
  // the element looked up fresh every time.
  el = get();
  if (!el || !el.isConnected) return { ok: false, method: method };
  focusField(el);
  selectAllIn(el);
  if (!insertText(el, '')) writeValue(el, '');

  for (const ch of value) {
    el = get();
    if (!el || !el.isConnected) return { ok: false, method: method };
    if (!isFocused(el)) focusField(el);
    dispatchKey(el, 'keydown', ch);
    dispatchKey(el, 'keypress', ch);
    if (!insertText(el, ch)) writeValue(el, fieldValue(el) + ch);
    dispatchKey(el, 'keyup', ch);
    await sleep(40);
  }
  method = 'keystrokes';

  await sleep(300);
  el = get();
  return { ok: !!(el && el.isConnected && matchesTyped(el, value)), method: method };
}

/**
 * Is this element focused? document.activeElement reports the shadow HOST for
 * anything inside a shadow root, so asking the element's own root is the only
 * answer that holds in both cases.
 */
function isFocused(el) {
  try {
    const root = el.getRootNode ? el.getRootNode() : document;
    if (root && root.activeElement === el) return true;
  } catch (_) { /* ignore */ }
  return document.activeElement === el;
}

/** Did the text survive the framework's change detection? */
function matchesTyped(el, value) {
  const want = digitsIn(value);
  const got = fieldValue(el);
  return want ? digitsIn(got).includes(want) : got.trim() === String(value).trim();
}

/** Click into a field the way a person would, then let the page react. */
async function clickField(el, times) {
  if (!el || !el.isConnected) return false;
  for (let i = 0; i < Math.max(1, times || 1); i++) {
    realClick(el);
    await sleep(150);
  }
  try { el.focus(); } catch (_) { /* ignore */ }
  await sleep(100);
  return isFocused(el);
}

function focusField(el) {
  try { el.focus(); } catch (_) { /* ignore */ }
  realClick(el);
  try { el.focus(); } catch (_) { /* ignore */ }
}

function selectAllIn(el) {
  try {
    if (el.select) el.select();
    else if (window.getSelection) {
      const range = document.createRange();
      range.selectNodeContents(el);
      const sel = window.getSelection();
      sel.removeAllRanges();
      sel.addRange(range);
    }
  } catch (_) { /* ignore */ }
}

/**
 * A real browser edit — fires trusted beforeinput/input events.
 *
 * execCommand ignores the element you pass and edits whatever currently has
 * focus. That is not a detail: with focus elsewhere it typed the recipient's
 * number into the calling panel's lookalike field on the right, so the compose
 * screen stayed empty and no dropdown ever opened. Refuse to run unless the
 * intended field really is focused, and let the caller fall back.
 */
function insertText(el, value) {
  try {
    if (!isFocused(el)) {
      try { el.focus(); } catch (_) { /* ignore */ }
      if (!isFocused(el)) return false;
    }
    const before = fieldValue(el);
    const ok = document.execCommand('insertText', false, value);
    // execCommand can report success without changing anything.
    return ok && (value === '' ? true : fieldValue(el) !== before);
  } catch (_) {
    return false;
  }
}

/** Direct write, for fields that don't take an execCommand edit. */
function writeValue(el, value) {
  if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
    setNativeValue(el, value);
    return;
  }
  el.textContent = value;
  el.dispatchEvent(new InputEvent('input', { bubbles: true, data: value, inputType: 'insertText' }));
}

/**
 * A full keystroke, as close to the real thing as script allows.
 *
 * Google's own handlers commonly drive an autocomplete from key events and read
 * keyCode/which, which are absent from a bare KeyboardEvent. composed:true lets
 * the event cross a shadow boundary, as a real one does.
 */
function dispatchKey(el, type, ch) {
  const code = String(ch).charCodeAt(0);
  const init = {
    key: ch,
    code: /\d/.test(ch) ? 'Digit' + ch : 'Key' + String(ch).toUpperCase(),
    keyCode: code,
    charCode: type === 'keypress' ? code : 0,
    which: code,
    bubbles: true,
    cancelable: true,
    composed: true
  };
  el.dispatchEvent(new KeyboardEvent(type, init));
}
/** What's currently in a field, whatever kind of field it is. */
function fieldValue(el) {
  if (!el) return '';
  if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') return String(el.value || '');
  return String(el.textContent || '');
}
function setNativeValue(input, value) {
  const proto = input.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
  setter.call(input, value);
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
}
function pressEnter(el) {
  el.focus();
  for (const type of ['keydown', 'keypress', 'keyup']) {
    el.dispatchEvent(new KeyboardEvent(type, {
      key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true, cancelable: true
    }));
  }
}
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

/* ---------- locating things for real input ---------- */

/**
 * Where is a given part of the page, in viewport coordinates?
 *
 * The side panel uses this to aim genuine browser-level clicks and keystrokes at
 * the right spot. Finding the element stays here, where all the page knowledge
 * lives; the panel only needs a point to aim at.
 */
function locateOnce(what, number) {
  let found = null;

  if (what === 'newMessageBtn') found = findElement(GV.newMessageBtn);
  else if (what === 'toField') found = findToField();
  else if (what === 'suggestion') found = suggestionFor(number, (findToField() || {}).el);
  else if (what === 'sendBtn') {
    found = findElement(GV.sendBtn);
    if (found && isDisabled(found.el)) found = null;
    if (!found) {
      const box = findElement(GV.messageBox);
      found = box ? nearbySendButton(box.el) : null;
    }
  } else if (what === 'messageBox' || what === 'emptyMessageBox') {
    found = findElement(GV.messageBox);
    if (found && isDisabled(found.el)) found = null;
    // The box must be empty for a fresh conversation — text already in it
    // belongs to someone else's thread.
    if (found && what === 'emptyMessageBox' && fieldValue(found.el).trim()) found = null;
  }

  if (!found || !found.el || !isVisible(found.el)) return null;

  const r = found.el.getBoundingClientRect();
  return {
    ok: true,
    x: Math.round(r.left + r.width / 2),
    y: Math.round(r.top + r.height / 2),
    how: found.how,
    value: fieldValue(found.el)
  };
}

function locateWait({ what, number, timeout }) {
  return poll(() => locateOnce(what, number), timeout || 8000)
    .then((hit) => hit || { ok: false, what: what });
}

/**
 * What is on screen around the To field right now? Used when a recipient row
 * fails to appear, so the failure says whether the row is missing or merely
 * unmatched — the difference between Google Voice not reacting and our search
 * being wrong.
 */
function diagnoseRecipient(number) {
  const to = findToField();
  const out = {
    ok: true,
    // Explicit, not inferred from toValue's text: '(no To field)' has no
    // digits in it either, and a caller checking "digits gone -> accepted"
    // must NOT read that string as the field having turned into a chip. The
    // field being genuinely GONE means we don't know where we are, which is
    // never itself a sign of success.
    toFound: !!to,
    toValue: to ? fieldValue(to.el) : '(no To field)',
    toFocused: to ? isFocused(to.el) : false,
    pageFocused: document.hasFocus(),
    matched: !!suggestionFor(number, to ? to.el : null),
    activeCall: looksLikeActiveCall(),
    // A second, independent way to confirm we're in the right conversation —
    // Google Voice addresses one by number in the URL (see sendToOpenThread).
    // If the compose field disappears once a recipient is accepted (rather
    // than turning into a visible chip, which this script has never fully
    // confirmed against the live page), this is what tells "we're genuinely
    // in the right conversation now" apart from "we have no idea where we are."
    urlNamesNumber: urlNames(number),
    // Third independent positive signal — see addRecipientsFieldPresent().
    // Covers the case the other two miss: the classic To field is gone (so
    // toFound is false) AND the URL hasn't picked up the number yet, but the
    // page has already moved into the post-accept "chip + Add recipients"
    // shape, which only exists once a recipient is set.
    addRecipientsFound: addRecipientsFieldPresent(),
    rows: []
  };
  if (!to) return out;

  const anchor = to.el.getBoundingClientRect();
  out.rows = pageElements()
    .filter((e) => {
      if (!isVisible(e)) return false;
      const t = renderedText(e);
      if (!t || t.length > 60) return false;
      const r = e.getBoundingClientRect();
      return r.top >= anchor.top && r.top - anchor.bottom < 260 &&
             r.right > anchor.left && r.left < anchor.right;
    })
    .sort((a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length)
    .slice(0, 6)
    .map((e) => renderedText(e).slice(0, 40));

  return out;
}

/** Did the message actually leave? The box empties once Google Voice sends. */
function messageBoxCleared() {
  const found = findElement(GV.messageBox);
  if (!found) return { ok: false, reason: 'the message box vanished' };
  return { ok: fieldValue(found.el).trim() === '', value: fieldValue(found.el) };
}

/**
 * The number of the Google Voice account signed into this tab — read straight
 * off the page, where it's always shown as "Call as (510) 214-3084" in the
 * calling panel. This is what identifies who's sending a blast: the side
 * panel matches this against the loaded contacts to find the real name, which
 * doesn't depend on Chrome's account APIs (chrome.identity.getProfileUserInfo
 * returned nothing at all for a real signed-in account — see sidepanel.js).
 *
 * Read-only, on purpose: this sits right next to the calling panel's number
 * field that sendOne() is careful never to type into, since a wrong write
 * there could place a call. Reading text near it carries none of that risk.
 */
function readAccountNumber() {
  const near = (text) => {
    const idx = String(text == null ? '' : text).toLowerCase().indexOf('call as');
    if (idx < 0) return null;
    const snippet = String(text).slice(idx, idx + 60);
    const m = snippet.match(/\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}/);
    return m ? digitsIn(m[0]) : null;
  };

  const direct = near(document.body.innerText);
  if (direct) return direct;

  // Fallback: walk every element (shadow roots included) in case innerText
  // missed this — the calling panel has been a source of surprises before.
  for (const el of pageElements()) {
    if (!isVisible(el)) continue;
    const t = renderedText(el);
    if (t && t.length < 200 && t.toLowerCase().includes('call as')) {
      const found = near(t);
      if (found) return found;
    }
  }
  return null;
}

/* ---------- probe (debug) ---------- */

/**
 * Opens a new message, types the number, and reports what actually appeared —
 * without sending anything. Built because three rounds of reasoning from error
 * messages produced three wrong guesses about the recipient dropdown. This
 * answers the question directly: is the row there, what does it say, where is
 * it, and is it inside a shadow root.
 */
async function probeRecipient({ phone, digits }) {
  const number = String(digits || phone || '').replace(/\D/g, '');

  const plus = await waitFor(GV.newMessageBtn, 8000);
  if (!plus) return { ok: false, error: 'Could not find the "+ Send new message" button' };
  realClick(plus.el);

  const to = findToField() || await waitFor(GV.toField, 8000);
  if (!to) return { ok: false, error: 'Could not find the "To" field' };
  const typed = await typeInto(() => (findToField() || {}).el, phone);
  await sleep(2000);   // give the dropdown time to open

  const anchor = to.el.getBoundingClientRect();
  const all = pageElements();
  const shadowHosts = all.filter((e) => e.shadowRoot).length;

  const describe = (e) => {
    const r = e.getBoundingClientRect();
    return {
      tag: e.tagName.toLowerCase(),
      role: e.getAttribute('role') || '',
      label: e.getAttribute('aria-label') || '',
      text: renderedText(e).slice(0, 60),
      top: Math.round(r.top),
      left: Math.round(r.left),
      inShadow: !!(e.getRootNode && e.getRootNode() !== document)
    };
  };
  const smallestFirst = (a, b) => a.querySelectorAll('*').length - b.querySelectorAll('*').length;

  // Anything on screen mentioning the number, wherever it is.
  const naming = all
    .filter((e) => {
      if (!isVisible(e)) return false;
      const raw = norm(e.textContent);
      return raw.length <= 80 && digitsIn(raw).includes(number);
    })
    .sort(smallestFirst).slice(0, 10).map(describe);

  // Anything sitting in the dropdown area under the To field, number or not.
  const below = all
    .filter((e) => {
      if (!isVisible(e)) return false;
      const t = renderedText(e);
      if (!t || t.length > 60) return false;
      const r = e.getBoundingClientRect();
      return r.top >= anchor.bottom && r.top - anchor.bottom < 250 &&
             r.right > anchor.left && r.left < anchor.right;
    })
    .sort((a, b) => a.getBoundingClientRect().top - b.getBoundingClientRect().top)
    .slice(0, 12).map(describe);

  return {
    ok: true,
    number,
    typedOk: typed.ok,
    typedBy: typed.method,
    pageFocused: document.hasFocus(),
    toValue: fieldValue(to.el),
    toRect: { top: Math.round(anchor.top), left: Math.round(anchor.left), width: Math.round(anchor.width) },
    elements: all.length,
    shadowHosts,
    matched: !!suggestionFor(number, to.el),
    naming,
    below
  };
}

/* ---------- capture (debug) ---------- */
function captureInterface() {
  const report = { url: location.href, found: {}, missing: [] };

  for (const [name, spec] of Object.entries(GV)) {
    const hit = findElement(spec);
    if (!hit) {
      report.found[name] = null;
      report.missing.push(name);
      continue;
    }
    report.found[name] = {
      what: spec.what,
      foundBy: hit.how,
      tag: hit.el.tagName,
      attributes: Array.from(hit.el.attributes || []).map(a => a.name + '="' + a.value + '"').join(' ').slice(0, 300),
      outerHTMLHead: hit.el.outerHTML.slice(0, 300)
    };
  }

  // Also dump likely interactive controls so a human can spot the right ones.
  report.buttons = queryDeep('button,[role=button],a[aria-label]')
    .filter(isVisible)
    .slice(0, 60)
    .map(b => ({ tag: b.tagName, label: b.getAttribute('aria-label') || norm(b.textContent).slice(0, 30) }))
    .filter(b => b.label);

  report.fields = fields().filter(isVisible).slice(0, 20).map(f => ({
    tag: f.tagName, placeholder: f.getAttribute('placeholder') || '', label: f.getAttribute('aria-label') || ''
  }));

  return report;
}
