// The side panel: renders the catalog, launches tools, and hosts super-admin
// mode. Runs as an extension page, so chrome.* is available directly.

import { MSG, TYPES, BUILT_IN_ICONS } from '../lib/constants.js';
import { groupItems } from '../lib/catalog.js';
import { openEditor, renderAdminBar, moveItem } from './admin.js';

const $ = (selector) => document.querySelector(selector);

const state = {
  catalog: null,
  settings: null,
  meta: null,
  admin: false,
  hasManagement: false,
  installed: {},
  favoriteSheets: [],
  websiteShortcuts: [],
  query: ''
};

// Shared with admin.js so the editor can read state and write it back.
const ctx = { state, save, toast, refresh, send, BUILT_IN_ICONS };

init();

async function init() {
  wire();
  await refresh();
  render();
  checkInstalled();

  // Opening the panel is the natural moment to look for a newer catalog.
  if (state.settings.syncOnOpen && state.settings.endpoint) {
    const result = await send({ type: MSG.SYNC_NOW });
    if (result.status === 'updated') {
      await refresh();
      render();
      toast(`Updated to v${result.version}.`);
    }
  }
}

// ---------------------------------------------------------------------------
// Data
// ---------------------------------------------------------------------------

function send(message) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(message, (response) => {
      void chrome.runtime.lastError;
      resolve(response || { ok: false, error: 'The extension did not respond.' });
    });
  });
}

async function refresh() {
  const response = await send({ type: MSG.GET_STATE });
  if (!response.ok) return;
  state.catalog = response.catalog;
  state.settings = response.settings;
  state.meta = response.meta;
  state.admin = response.admin;
  state.hasManagement = response.hasManagement;
  state.favoriteSheets = response.favoriteSheets || [];
  state.websiteShortcuts = response.websiteShortcuts || [];
}

/** Persist an edited catalog by writing it back to the spreadsheet. */
async function save(catalog) {
  const response = await send({ type: MSG.ADMIN_SAVE, catalog });
  if (!response.ok) {
    toast(response.error || 'Could not save to the sheet.', true);
    return false;
  }
  await refresh();
  render();
  return true;
}

async function checkInstalled() {
  const ids = [];
  for (const item of state.catalog.items) {
    if (item.type === TYPES.EXTENSION && item.target && !ids.includes(item.target)) {
      ids.push(item.target);
    }
  }
  if (!ids.length) return;

  const response = await send({ type: MSG.CHECK_INSTALLED, extensionIds: ids });
  if (response.ok && response.supported) {
    state.installed = response.installed;
    render();
  }
}

// ---------------------------------------------------------------------------
// Rendering
// ---------------------------------------------------------------------------

function render() {
  if (!state.catalog) return;

  $('#brand-title').textContent = state.catalog.branding.title;
  $('#brand-subtitle').textContent = state.catalog.branding.subtitle;
  $('#version').textContent = state.catalog.version ? `v${state.catalog.version}` : '';
  $('#btn-admin').classList.toggle('on', state.admin);
  $('#admin-label').textContent = state.admin ? 'Admin mode on' : 'Super admin';

  renderStatus();
  renderTools();
}

function renderStatus() {
  const node = $('#status');
  const { lastSyncError, lastSyncAt } = state.meta;

  if (!state.settings.endpoint) {
    node.innerHTML = '<b>Not connected yet.</b> Open settings to add the spreadsheet link.';
    return;
  }
  if (lastSyncError) {
    node.innerHTML = `<b>Could not reach the sheet.</b> ${escapeHtml(lastSyncError)}`;
    return;
  }
  node.innerHTML = lastSyncAt
    ? `<b>Up to date.</b> Checked ${relativeTime(lastSyncAt)}.`
    : '<b>Ready.</b>';
}

function renderTools() {
  const root = $('#tools');
  root.replaceChildren();

  if (state.admin) root.appendChild(renderAdminBar(ctx));

  const query = state.query.trim().toLowerCase();
  let shown = 0;

  for (const kind of [PERSONAL_KINDS.sheet, PERSONAL_KINDS.link]) {
    const section = renderPersonalSection(kind);
    if (section) {
      root.appendChild(section.node);
      shown += section.count;
    }
  }

  // Always the same two sections, in the same order. A section with nothing in
  // it is hidden from the team but stays visible in admin mode, so there is
  // somewhere to add the first tool.
  groupItems(state.catalog).forEach((section) => {
    const items = section.items.filter((item) => {
      if (!state.admin && !item.enabled) return false;
      if (!query) return true;
      return (
        item.name.toLowerCase().includes(query) ||
        item.description.toLowerCase().includes(query) ||
        section.name.toLowerCase().includes(query)
      );
    });

    if (!items.length && !state.admin) return;

    const wrapper = document.createElement('section');
    wrapper.className = 'section';

    const head = document.createElement('h2');
    head.className = 'section-head';
    const label = document.createElement('span');
    label.textContent = section.name;
    const rule = document.createElement('span');
    rule.className = 'rule';
    head.append(label, rule);
    if (state.admin) {
      head.appendChild(
        mini('＋', `Add to ${section.name}`, () => openEditor(ctx, { type: section.key }))
      );
    }
    wrapper.appendChild(head);

    items.forEach((item, index) => {
      wrapper.appendChild(renderTool(item, index, items.length));
      shown += 1;
    });

    if (!items.length) {
      const none = document.createElement('p');
      none.className = 'section-empty';
      none.textContent = query ? 'Nothing matches here.' : 'Nothing here yet.';
      wrapper.appendChild(none);
    }

    root.appendChild(wrapper);
  });

  if (!shown && !state.admin) root.appendChild(renderEmpty(Boolean(query)));
}

function renderEmpty(searching) {
  const box = document.createElement('div');
  box.className = 'empty';

  if (searching) {
    box.textContent = `Nothing matches “${state.query}”.`;
    return box;
  }
  if (!state.settings.endpoint) {
    box.innerHTML = '<b>Not connected</b>The drawer needs the link to your spreadsheet.';
    const button = document.createElement('button');
    button.className = 'primary';
    button.type = 'button';
    button.textContent = 'Open settings';
    button.addEventListener('click', () => send({ type: MSG.OPEN_OPTIONS }));
    box.appendChild(document.createElement('br'));
    box.appendChild(button);
    return box;
  }
  box.innerHTML = '<b>No tools yet</b>Add the first one from the Tools tab of the sheet, or unlock super admin.';
  return box;
}

// ---------------------------------------------------------------------------
// My Spreadsheets and Website Shortcuts — personal, per-browser shortcuts.
// Never part of the shared catalog, never written to the spreadsheet. Both
// sections work the same way (a list of links, added through one link field,
// removed with a confirm), so one mechanism drives both — same idea as the
// tool editor reusing one modal for an app and an extension.
// ---------------------------------------------------------------------------

const PERSONAL_KINDS = {
  sheet: {
    icon: 'i-sheet',
    sectionTitle: 'My Spreadsheets',
    addLabel: 'Add a spreadsheet',
    modalTitle: 'Add a spreadsheet',
    modalCopy: "Only in your own drawer. It isn't added to the shared spreadsheet, and nobody else sees it.",
    linkLabel: 'Spreadsheet link',
    placeholder: 'https://docs.google.com/spreadsheets/d/…',
    hint: 'The button is named after the spreadsheet itself.',
    detectingText: 'Reading the spreadsheet’s name…',
    detectFailedText:
      "Couldn't read a name from that link — the sheet may need a different Google " +
      'account, or the link may be wrong. Type a name instead:',
    stateKey: 'favoriteSheets',
    addMsg: MSG.ADD_FAVORITE_SHEET,
    removeMsg: MSG.REMOVE_FAVORITE_SHEET,
    reorderMsg: MSG.REORDER_FAVORITE_SHEET
  },
  link: {
    icon: 'i-link',
    sectionTitle: 'Website Shortcuts',
    addLabel: 'Add a website',
    modalTitle: 'Add a website',
    modalCopy: "Only in your own drawer. It isn't added to the shared spreadsheet, and nobody else sees it.",
    linkLabel: 'Website link',
    placeholder: 'https://…',
    hint: 'The button is named after the page’s own title.',
    detectingText: 'Reading the page’s title…',
    detectFailedText:
      "Couldn't find that page open in any of your tabs, so its title can't be read. " +
      'Open it in a tab first, or type a name instead:',
    stateKey: 'websiteShortcuts',
    addMsg: MSG.ADD_WEBSITE_SHORTCUT,
    removeMsg: MSG.REMOVE_WEBSITE_SHORTCUT,
    reorderMsg: MSG.REORDER_WEBSITE_SHORTCUT
  }
};

function renderPersonalSection(kind) {
  const query = state.query.trim().toLowerCase();
  const entries = state[kind.stateKey].filter(
    (entry) => !query || entry.name.toLowerCase().includes(query)
  );
  if (!entries.length && query) return null; // nothing to show while searching

  const wrapper = document.createElement('section');
  wrapper.className = 'section';

  const head = document.createElement('h2');
  head.className = 'section-head';
  const label = document.createElement('span');
  label.textContent = kind.sectionTitle;
  const rule = document.createElement('span');
  rule.className = 'rule';
  head.append(label, rule);
  wrapper.appendChild(head);

  entries.forEach((entry) => wrapper.appendChild(renderPersonalRow(entry, kind)));

  if (!query) {
    const addButton = document.createElement('button');
    addButton.className = 'tool-add';
    addButton.type = 'button';
    addButton.innerHTML = `<span class="plus">+</span><span>${kind.addLabel}</span>`;
    addButton.addEventListener('click', () => openPersonalModal(kind));
    wrapper.appendChild(addButton);
  }

  return { node: wrapper, count: entries.length };
}

function renderPersonalRow(entry, kind) {
  const row = document.createElement('div');
  row.className = 'tool';
  row.draggable = false;

  row.appendChild(dragHandle(row, entry, kind));

  const launcher = document.createElement('button');
  launcher.className = 'tool-launch';
  launcher.type = 'button';

  const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  icon.setAttribute('class', 'tool-icon');
  const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
  use.setAttribute('href', `#${kind.icon}`);
  icon.appendChild(use);
  launcher.appendChild(icon);

  const body = document.createElement('span');
  body.className = 'tool-body';
  const name = document.createElement('span');
  name.className = 'tool-name';
  const label = document.createElement('span');
  label.className = 'tool-label';
  label.textContent = entry.name;
  name.appendChild(label);
  body.appendChild(name);
  launcher.appendChild(body);

  launcher.addEventListener('click', () => chrome.tabs.create({ url: entry.url }));
  row.appendChild(launcher);

  row.appendChild(confirmMini(`Remove ${entry.name}`, () => removePersonalEntry(entry, kind)));

  wireDragEvents(row, entry, kind);

  return row;
}

/** A small grip that's the only part of the row that can start a drag — the
    row itself stays non-draggable the rest of the time, so grabbing the name
    or the remove button never accidentally moves it. */
function dragHandle(row, entry, kind) {
  const handle = document.createElement('span');
  handle.className = 'drag-handle';
  handle.title = `Drag to reorder ${entry.name}`;
  handle.innerHTML =
    '<svg width="10" height="16" viewBox="0 0 10 16" aria-hidden="true"><g fill="currentColor">' +
    '<circle cx="2" cy="2" r="1.3" /><circle cx="8" cy="2" r="1.3" />' +
    '<circle cx="2" cy="8" r="1.3" /><circle cx="8" cy="8" r="1.3" />' +
    '<circle cx="2" cy="14" r="1.3" /><circle cx="8" cy="14" r="1.3" />' +
    '</g></svg>';

  handle.addEventListener('mousedown', () => {
    row.draggable = true;
    window.addEventListener('mouseup', () => { row.draggable = false; }, { once: true });
  });

  return handle;
}

let dragState = null;

function wireDragEvents(row, entry, kind) {
  row.addEventListener('dragstart', (event) => {
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData('text/plain', entry.id);
    dragState = { kind, id: entry.id };
    row.classList.add('dragging');
  });

  row.addEventListener('dragend', () => {
    row.draggable = false;
    row.classList.remove('dragging');
    dragState = null;
  });

  row.addEventListener('dragover', (event) => {
    if (!dragState || dragState.kind !== kind || dragState.id === entry.id) return;
    event.preventDefault();
    event.dataTransfer.dropEffect = 'move';
    row.classList.add('drag-over');
  });

  row.addEventListener('dragleave', () => row.classList.remove('drag-over'));

  row.addEventListener('drop', (event) => {
    event.preventDefault();
    row.classList.remove('drag-over');
    if (!dragState || dragState.kind !== kind || dragState.id === entry.id) return;
    reorderPersonalEntries(kind, dragState.id, entry.id);
  });
}

async function reorderPersonalEntries(kind, draggedId, targetId) {
  const list = state[kind.stateKey];
  const from = list.findIndex((e) => e.id === draggedId);
  const to = list.findIndex((e) => e.id === targetId);
  if (from === -1 || to === -1 || from === to) return;

  const previous = list;
  const next = list.slice();
  const [moved] = next.splice(from, 1);
  next.splice(to, 0, moved);

  // Reorder on screen right away — waiting on the round trip would make a
  // drag feel laggy for a save that essentially never fails.
  state[kind.stateKey] = next;
  renderTools();

  const response = await send({ type: kind.reorderMsg, order: next.map((e) => e.id) });
  if (!response.ok) {
    state[kind.stateKey] = previous;
    renderTools();
    toast(response.error || 'Could not save the new order.', true);
  }
}

/** Same two-click confirmation as the admin delete button, sized for a row's
    corner instead of a modal footer — window.confirm() isn't reliable in
    every extension surface. */
function confirmMini(label, onConfirm) {
  const button = document.createElement('button');
  button.className = 'mini';
  button.type = 'button';
  button.title = label;
  button.textContent = '✕';

  let armed = false;
  let timer = null;

  button.addEventListener('click', (event) => {
    event.stopPropagation();
    if (armed) {
      clearTimeout(timer);
      onConfirm();
      return;
    }
    armed = true;
    button.classList.add('confirm');
    button.title = 'Click again to remove';
    timer = setTimeout(() => {
      armed = false;
      button.classList.remove('confirm');
      button.title = label;
    }, 4000);
  });

  return button;
}

async function removePersonalEntry(entry, kind) {
  const response = await send({ type: kind.removeMsg, id: entry.id });
  if (!response.ok) {
    toast(response.error || 'Could not remove that.', true);
    return;
  }
  state[kind.stateKey] = state[kind.stateKey].filter((e) => e.id !== entry.id);
  renderTools();
  toast(`Removed “${entry.name}”.`);
}

let activeKind = null;
let personalNeedsManualName = false;

function openPersonalModal(kind) {
  activeKind = kind;
  personalNeedsManualName = false;

  $('#personal-title').textContent = kind.modalTitle;
  $('#personal-copy').textContent = kind.modalCopy;
  $('#personal-link-label').textContent = kind.linkLabel;
  $('#personal-url').placeholder = kind.placeholder;
  $('#personal-hint').textContent = kind.hint;

  $('#personal-form').reset();
  $('#personal-name-row').hidden = true;
  $('#personal-status').hidden = true;
  $('#personal-error').hidden = true;
  $('#personal-submit').disabled = false;
  $('#personal-submit').textContent = 'Add';
  $('#personal-modal').hidden = false;
  $('#personal-url').focus();
}

async function submitPersonal(event) {
  event.preventDefault();
  const kind = activeKind;
  const error = $('#personal-error');
  const status = $('#personal-status');
  const submit = $('#personal-submit');
  const url = $('#personal-url').value.trim();
  const nameInput = $('#personal-name');

  error.hidden = true;

  if (personalNeedsManualName) {
    const name = nameInput.value.trim();
    if (!name) return fail(error, 'Enter a name for the button.');
    submit.disabled = true;
    await addPersonalEntry(kind, url, name);
    return;
  }

  submit.disabled = true;
  submit.textContent = 'Adding…';
  status.hidden = false;
  status.className = 'detect-status busy';
  status.innerHTML = `<span class="detect-spinner"></span> ${kind.detectingText}`;

  await addPersonalEntry(kind, url);
}

async function addPersonalEntry(kind, url, name) {
  const submit = $('#personal-submit');
  const status = $('#personal-status');
  const error = $('#personal-error');

  const response = await send({ type: kind.addMsg, url, name });
  submit.disabled = false;

  if (response.ok) {
    state[kind.stateKey] = [...state[kind.stateKey], response.entry];
    $('#personal-modal').hidden = true;
    renderTools();
    toast(`Added “${response.entry.name}”.`);
    return;
  }

  if (response.needsName && !personalNeedsManualName) {
    personalNeedsManualName = true;
    $('#personal-name-row').hidden = false;
    $('#personal-name').focus();
    submit.textContent = 'Add with this name';
    status.className = 'detect-status fail';
    status.textContent = kind.detectFailedText;
    return;
  }

  status.hidden = true;
  submit.textContent = personalNeedsManualName ? 'Add with this name' : 'Add';
  fail(error, response.error || 'Could not add that.');
}

function renderTool(item, index, count) {
  const row = document.createElement('div');
  row.className = 'tool';
  if (!item.enabled) row.classList.add('off');

  const launcher = document.createElement('button');
  launcher.className = 'tool-launch';
  launcher.type = 'button';

  launcher.appendChild(renderIcon(item));

  const body = document.createElement('span');
  body.className = 'tool-body';

  const name = document.createElement('span');
  name.className = 'tool-name';
  const label = document.createElement('span');
  label.className = 'tool-label';
  label.textContent = item.name;
  name.appendChild(label);

  const missing = isMissing(item);
  if (missing) name.appendChild(chip('not installed', true));
  if (state.admin && !item.enabled) name.appendChild(chip('off', false));
  body.appendChild(name);

  if (item.description) {
    const desc = document.createElement('span');
    desc.className = 'tool-desc';
    desc.textContent = item.description;
    body.appendChild(desc);
  }

  launcher.appendChild(body);
  launcher.addEventListener('click', () => (missing ? offerInstall(item) : launch(item)));
  row.appendChild(launcher);

  if (state.admin) {
    const controls = document.createElement('span');
    controls.className = 'tool-admin';
    controls.appendChild(mini('✎', 'Edit', () => openEditor(ctx, { itemId: item.id })));

    // While a search filters the list, on-screen position no longer maps to
    // position in the sheet, so reordering would move things unpredictably.
    if (!state.query.trim()) {
      if (index > 0) controls.appendChild(mini('↑', 'Move up', () => moveItem(ctx, item.id, -1)));
      if (index < count - 1) {
        controls.appendChild(mini('↓', 'Move down', () => moveItem(ctx, item.id, 1)));
      }
    }
    row.appendChild(controls);
  }

  return row;
}

function renderIcon(item) {
  if (BUILT_IN_ICONS.includes(item.icon)) {
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', 'tool-icon');
    const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    use.setAttribute('href', `#i-${item.icon}`);
    svg.appendChild(use);
    return svg;
  }

  const img = document.createElement('img');
  img.className = 'tool-icon';
  img.src = item.icon;
  img.alt = '';
  // A dead image URL should not leave a broken-image glyph in the row.
  img.addEventListener('error', () => {
    const fallback = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    fallback.setAttribute('class', 'tool-icon');
    const use = document.createElementNS('http://www.w3.org/2000/svg', 'use');
    use.setAttribute('href', item.type === TYPES.APP ? '#i-app' : '#i-link');
    fallback.appendChild(use);
    img.replaceWith(fallback);
  });
  return img;
}

function chip(text, missing) {
  const node = document.createElement('span');
  node.className = missing ? 'chip missing' : 'chip';
  node.textContent = text;
  return node;
}

function mini(label, title, handler) {
  const button = document.createElement('button');
  button.className = 'mini';
  button.type = 'button';
  button.title = title;
  button.textContent = label;
  button.addEventListener('click', (event) => {
    event.stopPropagation();
    handler();
  });
  return button;
}

function isMissing(item) {
  if (item.type !== TYPES.EXTENSION || !item.target || !state.hasManagement) return false;
  return state.installed[item.target] === false;
}

// ---------------------------------------------------------------------------
// Actions
// ---------------------------------------------------------------------------

async function launch(item) {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const response = await send({ type: MSG.LAUNCH, itemId: item.id, tabId: tab && tab.id });
  if (!response.ok) toast(response.error || 'Could not open that tool.', true);
}

function offerInstall(item) {
  if (item.installLink) {
    chrome.tabs.create({ url: item.installLink });
    return;
  }
  toast(`${item.name} is not installed, and no install link is set for it.`, true);
}

async function syncNow() {
  const button = $('#btn-sync');
  button.classList.add('spinning');
  const response = await send({ type: MSG.SYNC_NOW, force: true });
  button.classList.remove('spinning');

  await refresh();
  render();

  const messages = {
    updated: `Updated to v${response.version}.`,
    current: 'Already up to date.',
    'not-configured': 'No spreadsheet is connected yet.'
  };
  toast(messages[response.status] || response.error || 'Could not check.', response.status === 'error');
}

// ---------------------------------------------------------------------------
// Super admin
// ---------------------------------------------------------------------------

async function toggleAdmin() {
  if (state.admin) {
    await send({ type: MSG.ADMIN_LOCK });
    await refresh();
    render();
    toast('Admin mode off.');
    return;
  }

  if (!state.settings.endpoint) {
    toast('Connect the spreadsheet first, in settings.', true);
    return;
  }

  $('#unlock-password').value = '';
  $('#unlock-error').hidden = true;
  $('#unlock-modal').hidden = false;
  $('#unlock-password').focus();
}

async function submitUnlock(event) {
  event.preventDefault();
  const error = $('#unlock-error');
  const submit = $('#unlock-submit');

  submit.disabled = true;
  submit.textContent = 'Checking…';
  const response = await send({ type: MSG.ADMIN_VERIFY, password: $('#unlock-password').value });
  submit.disabled = false;
  submit.textContent = 'Unlock';

  if (!response.ok) {
    error.textContent = response.error;
    error.hidden = false;
    return;
  }
  if (!response.valid) {
    error.textContent = 'That password is not right.';
    error.hidden = false;
    return;
  }

  await refresh();
  $('#unlock-modal').hidden = true;
  render();
  toast('Admin mode on. Edits save straight to the sheet.');
}

// ---------------------------------------------------------------------------
// Wiring
// ---------------------------------------------------------------------------

function wire() {
  $('#btn-sync').addEventListener('click', syncNow);
  $('#btn-settings').addEventListener('click', () => send({ type: MSG.OPEN_OPTIONS }));
  $('#btn-admin').addEventListener('click', toggleAdmin);
  $('#unlock-form').addEventListener('submit', submitUnlock);
  $('#personal-form').addEventListener('submit', submitPersonal);

  $('#search').addEventListener('input', (event) => {
    state.query = event.target.value;
    renderTools();
  });

  for (const button of document.querySelectorAll('[data-close]')) {
    button.addEventListener('click', () => {
      $(`#${button.dataset.close}`).hidden = true;
    });
  }

  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape') return;
    const open = [...document.querySelectorAll('.modal')].find((modal) => !modal.hidden);
    if (open) open.hidden = true;
  });

  chrome.runtime.onMessage.addListener((message) => {
    if (message && message.type === MSG.CATALOG_CHANGED) refresh().then(render);
  });
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

let toastTimer = null;
function toast(message, isError = false) {
  const node = $('#toast');
  node.textContent = message;
  node.classList.toggle('error', isError);
  node.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    node.hidden = true;
  }, isError ? 7000 : 3400);
}

function relativeTime(timestamp) {
  const seconds = Math.round((Date.now() - timestamp) / 1000);
  if (seconds < 60) return 'just now';
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) return `${minutes} minute${minutes === 1 ? '' : 's'} ago`;
  const hours = Math.round(minutes / 60);
  if (hours < 24) return `${hours} hour${hours === 1 ? '' : 's'} ago`;
  return `${Math.round(hours / 24)} day(s) ago`;
}

function fail(node, message) {
  node.textContent = message;
  node.hidden = false;
}

function escapeHtml(value) {
  return String(value).replace(
    /[&<>"']/g,
    (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]
  );
}
